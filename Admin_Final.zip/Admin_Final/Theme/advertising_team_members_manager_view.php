<?php 
  include("header.php");
?>
<style type="text/css">
 
 .left_panel{
   background-color:#2B2B2B;
   
   border-radius: 4px;
   color:#ffffff;
   border:0px;
 }
 .right_panel{
  background-color:#2B2B2B;
  margin-left: -1%;
  width:105%;
  border-radius: 4px solid;
  color:#ffffff;
  border:0px;

 }
 .bottom_panel{
  background-color:#2B2B2B;
  width:101.5%;
  border-radius: 4px;
  color:#ffffff;
  border:0px;

 }
 .pnel-heding{
   font-size:14px;
   margin-top:-3px;
 }
 .table_hd_not_Active{
  color: #828282;
  margin-top: -50px;
 }
 .left_side_ads_values{
  font-size:30px;
   font-weight:bold;
 }
 .select_style{background-color:#1A1B20;
  border-radius:2px;
  border:0px;}
  .table-striped > tbody > tr:nth-child(2n+1) > td, .table-striped > tbody > tr:nth-child(2n+1) > th {
   background-color: #2B2B2B;
   color: #ffffff;
   height: 40px;
   padding-left: 10px;
}
.table-striped > tbody > tr:nth-child(2n) > td, .table-striped > tbody > tr:nth-child(2n) > th {
   padding-left: 10px;
   color: #ffffff;
   height: 60px;
}
th{border:1px solid #424242;}


</style>

<section id="container" >
    <?php 
      include("heading.php");
    ?>
    <link rel="stylesheet" type="text/css" href="star_icon/styles.css">
    <?php 
      include("sidemenu.php");
    ?>
    <!--/*************main content************/-->

    <section id="main-content">
    	 <section class="wrapper">
        
          <div class="row mt" style="margin-top:0px;margin-left:-25px;margin-right:-25px;">
            <div class="col-lg-12 col-md-12 col-xlg-12">
              <div class="col-lg-12 noSidePadding">
                
              </div>
              <div class="col-lg-12 noSidePadding">
                <div class="form-panel" style="font-size:13px; background-color:#1B1A20;">    					
                  <div class="panel-body" >
                     <div class="row">
                         <div class="col-xs-8 col-md-8">
                             <form>
                               <div class="form-group" style="margin-top:-10px;">
                                 <input type="text" name="search" class="form-control" placeholder="Search......." style="border-radius:0px;color:#ffffff;background-color:#2B2B2B;border-color:#2B2B2B;" />
                               </div>
                             </form>
                         </div>
                         <div class="col-xs-4 col-md-4">
                           <div class="row">
                             <div class="col-xs-6 col-md-6" style="color:#ffffff;" class="pull-right"><span class="icon icon-notify" style="margin-left:98%"></span>&nbsp;Notifications</div>
                             <div class="col-xs-6 col-md-6" style="color:#ffffff;"><div class="pull-right"><span class="icon icon-email5"></span>&nbsp;Mail</div></div>
                           </div>
                            
                         </div>
                     </div>
                     <div class="row">
                       <div class="col-xs-12 col-md-12">
                         <table class="table-striped" style="width:100%;" cellpadding="10" >
                            <tr>
                           <th style="width:10%;">ID</th>
                           <th style="width:25%;">NAME</th>
                           <th style="width:30%;">Rank</th>
                           <th style="width:35%;">EMAIL</th>
                           </tr>
                           <tr>
                            <td>23A4</td>
                            <td>Kevin Gasta</td>
                            <td><div class="col-md-6" style="margin-left:-14px;">Team Leder &nbsp;&nbsp; </div><div style="margin-left:-60px;" class="col-md-6"><span style="color:red;font-size:16px;" class="icon icon-star"></span></div></td>
                            <td>kevingasta@gmail.com</td>
                           </tr>
                           <tr>
                            <td>23A4</td>
                            <td>Kevin Gasta</td>
                            <td>Team</td>
                            <td>kevingasta@gmail.com</td>
                           </tr>
                           <tr>
                            <td>23A4</td>
                            <td>Kevin Gasta</td>
                            <td>Team</td>
                            <td>kevingasta@gmail.com</td>
                           </tr>
                           <tr>
                            <td>23A4</td>
                            <td>Kevin Gasta</td>
                            <td>Team</td>
                            <td>kevingasta@gmail.com</td>
                           </tr>
                           <tr>
                            <td>23A4</td>
                            <td>Kevin Gasta</td>
                            <td>Team</td>
                            <td>kevingasta@gmail.com</td>
                           </tr>
                           <tr>
                            <td>23A4</td>
                            <td>Kevin Gasta</td>
                            <td>Team</td>
                            <td>kevingasta@gmail.com</td>
                           </tr>
                           <tr>
                            <td>23A4</td>
                            <td>Kevin Gasta</td>
                            <td>Team</td>
                            <td>kevingasta@gmail.com</td>
                           </tr>
                           <tr>
                            <td>23A4</td>
                            <td>Kevin Gasta</td>
                            <td>Team</td>
                            <td>kevingasta@gmail.com</td>
                           </tr>
                           <tr>
                            <td>23A4</td>
                            <td>Kevin Gasta</td>
                            <td>Team</td>
                            <td>kevingasta@gmail.com</td>
                           </tr>
                           <tr>
                            <td>23A4</td>
                            <td>Kevin Gasta</td>
                            <td>Team</td>
                            <td>kevingasta@gmail.com</td>
                           </tr>
                           <tr>
                            <td>23A4</td>
                            <td>Kevin Gasta</td>
                            <td>Team</td>
                            <td>kevingasta@gmail.com</td>
                           </tr>
                           <tr>
                            <td>23A4</td>
                            <td>Kevin Gasta</td>
                            <td>Team</td>
                            <td>kevingasta@gmail.com</td>
                           </tr>
                           <tr>
                            <td>23A4</td>
                            <td>Team</td>
                            <td>Kevin Gasta</td>
                            <td>kevingasta@gmail.com</td>
                           </tr>
                           <tr>
                            <td>23A4</td>
                            <td>Kevin Gasta</td>
                            <td>Team</td>
                            <td>kevingasta@gmail.com</td>
                           </tr>
                           <tr>
                            <td>23A4</td>
                            <td>Kevin Gasta</td>
                            <td>Team</td>
                            <td>kevingasta@gmail.com</td>
                           </tr>
                           <tr>
                            <td>23A4</td>
                            <td>Kevin Gasta</td>
                            <td>Team</td>
                            <td>kevingasta@gmail.com</td>
                           </tr>
                           <tr>
                            <td>23A4</td>
                            <td>Kevin Gasta</td>
                            <td>Team</td>
                            <td>kevingasta@gmail.com</td>
                           </tr>
                           <tr>
                            <td>23A4</td>
                            <td>Kevin Gasta</td>
                            <td>Team</td>
                            <td>kevingasta@gmail.com</td>
                           </tr>
                           <tr>
                            <td>23A4</td>
                            <td>Kevin Gasta</td>
                            <td>Team</td>
                            <td>kevingasta@gmail.com</td>
                           </tr>
                         </table>
                       </div>
                      </div>
                     
                  </div>
                </div>
              </div>
            </div>
	
          </div>

        <br/><br/><br/><br/><br/><br/>
    	</section>

    </section>
    <!--***************end content**************-->

  <?php
      include("footing.php");
    ?>

</section>

<?php 
  include("footer.php");
?>
