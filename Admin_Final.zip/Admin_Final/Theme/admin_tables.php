<?php
	if($user_type=="Supervisor"){
			$table="supervisor_ads_assigned";
	}elseif ($user_type=="Operator") {
		$table="operator_ads_assigned";
	}
 ?>