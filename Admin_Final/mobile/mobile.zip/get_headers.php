<?php
 	header("Content-type: application/json");  
 ?>