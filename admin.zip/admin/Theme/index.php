<?php 
  include("header.php");
?>

  <section id="container" >
    <?php 
      include("heading.php");
    ?>

    <?php 
      include("sidemenu.php");
    ?>

    <?php 
      //include("dashboard.php");
    ?> 
    
    <?php
      include("footing.php");
    ?>
    
      
  </section>

<?php
  include("footer.php");
?>