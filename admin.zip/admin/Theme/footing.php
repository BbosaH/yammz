<!--footer start-->
      <footer class="site-footer" style="position:fixed; bottom: 0; width: 100%">
          <div class="text-center">
              <?php echo date('Y'); ?> - yammzit.com
              <a href="<?php echo $_SERVER['PHP_SELF']; ?>#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>
      <!--footer end-->