<?php
class henry
{
	private $nose;
	private $mouth;
	private $ears;


	/**
	 * Class Constructor
	 * @param    $nose   
	 * @param    $mouth   
	 * @param    $ears   
	 */
	public function __construct($nose, $mouth, $ears)
	{
		$this->nose = $nose;
		$this->mouth = $mouth;
		$this->ears = $ears;
	}
	
}

?>
