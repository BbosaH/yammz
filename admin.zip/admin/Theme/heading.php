 <!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
      <!--header start-->
      <header class="header yammzit">
              <div class="sidebar-toggle-box whiteColor">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a href="index.php" class="logo">
              <img src="assets/img/redLogo.PNG" class="header-logo" />
              <span class="whiteColor">YAMMZ IT</span>
            </a>
            <!--logo end-->
            
            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li>
                      <form action="../index.php" method="POST">
                        <button class="logout btn btn-default" name="logout">
                          <i class="fa fa-sign-out"></i> Logout
                        </button>
                      </form>
                      
                    </li>
            	</ul>
            </div>
        </header>
      <!--header end-->