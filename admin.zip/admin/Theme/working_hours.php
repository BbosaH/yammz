<table style="font-size:14px;">
	<tr style="padding-bottom:100px;">
		<td width="50px"><B>Mon<B></td>
		<td width="110px">
			<select id="sl_privileges" name="mon_f" class="form-control" style="border-radius:0; width:100px; height:28px; border-color:#868686;">
				<option value=""></option>							
			</select>
		</td>
		<td width="25px"><B> to<B> </td>
		<td>
			<select id="sl_privileges" name="mon_t" class="form-control" style="border-radius:0; width:100px; height:28px; border-color:#868686;">
				<option value=""></option>	
				<option value="1">6:00AM</option>							
			</select>
		</td>
	</tr>
	</table>
	&nbsp;
	<table style="font-size:14px;">
	<tr>
		<td width="50px"><B>Tue<B></td>
		<td width="110px">
			<select id="sl_privileges" name="tue_f" class="form-control" style="border-radius:0; width:100px; height:28px; border-color:#868686;">
				<option value=""></option>							
			</select>
		</td>
		<td width="25px"> <B>to <B></td>
		<td>
			<select id="sl_privileges" name="tue_t" class="form-control" style="border-radius:0; width:100px; height:28px; border-color:#868686;">
				<option value=""></option>								
			</select>
		</td>
	</tr>
	</table>
	&nbsp;
	<table style="font-size:14px;">
	<tr>
		<td width="50px"><B>Wed<B></td>
		<td width="110px">
			<select id="sl_privileges" name="wed_f"class="form-control" style="border-radius:0; width:100px; height:28px; border-color:#868686;">
				<option value=""></option>							
			</select>
		</td>
		<td width="25px"><B> to <B></td>
		<td>
			<select id="sl_privileges" name="wed_t" class="form-control" style="border-radius:0; width:100px; height:28px; border-color:#868686;">
				<option value=""></option>								
			</select>
		</td>
	</tr>
	</table>
	&nbsp;
	<div id="addhours" class="collapse out">
		<table style="font-size:14px;">
			<tr>
				<td width="50px"><B>Thur<B></td>
				<td width="110px">
					<select id="sl_privileges" name="thur_f" class="form-control" style="border-radius:0; width:100px; height:28px; border-color:#868686;">
						<option value=""></option>								
					</select>
				</td>
				<td width="25px"><B> to <B></td>
				<td>
					<select id="sl_privileges" name="thur_t" class="form-control" style="border-radius:0; width:100px; height:28px; border-color:#868686;">
						<option value=""></option>								
					</select>
				</td>
			</tr>
		</table>
		&nbsp;
		<table style="font-size:14px;">
			<tr>
				<td width="50px"><B>Fri<B></td>
				<td width="110px">
					<select id="sl_privileges" name="fri_f" class="form-control" style="border-radius:0; width:100px; height:28px; border-color:#868686;">
						<option value=""></option>							
					</select>
				</td>
				<td width="25px"><B> to <B></td>
				<td>
					<select id="sl_privileges" name="fri_t"class="form-control" style="border-radius:0; width:100px; height:28px; border-color:#868686;">
						<option value=""></option>								
					</select>
				</td>
			</tr>
		</table>
		&nbsp;
		<table style="font-size:14px;">
			<tr>
				<td width="50px"><B>Sat<B></td>
				<td width="110px">
					<select id="sl_privileges" name="sat_f" class="form-control" style="border-radius:0; width:100px; height:28px; border-color:#868686;">
						<option value=""></option>							
					</select>
				</td>
				<td width="25px"><B> to <B></td>
				<td>
					<select id="sl_privileges" name="sat_t" class="form-control" style="border-radius:0; width:100px; height:28px; border-color:#868686;">
						<option value=""></option>							
					</select>
				</td>
			</tr>
		</table>
		&nbsp;
		<table style="font-size:14px;">
			<tr>
				<td width="50px"><B>Sun<B></td>
				<td width="110px">
					<select id="sl_privileges" name="sun_f" class="form-control" style="border-radius:0; width:100px; height:28px; border-color:#868686;">
						<option value=""></option>								
					</select>
				</td>
				<td width="25px"><B> to <B></td>
				<td>
					<select id="sl_privileges" name="sun_t"class="form-control" style="border-radius:0; width:100px; height:28px; border-color:#868686;">
						<option value=""></option>								
					</select>
				</td>
			</tr>
		</table>
	</div>
	<br/>
	<a class=" btn redbright" data-toggle="collapse"style="height:30px;border-radius:4; background-color:#BD2532;color:white;" data-target="#addhours">Add Work Hours</a>
