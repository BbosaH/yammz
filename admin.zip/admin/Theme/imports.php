<?php
require_once('Controllers/auth/auth.php');
include('Controllers/like/like_functions.php');

?>
<!DOCTYPE HTML>
<html>
<head>
<!-- load jquery -->

<link rel="stylesheet" href="css.css">
<link href="dist/css/bootstrap.min.css" rel="stylesheet">
<link href="carousel.css" rel="stylesheet">
<link rel="shortcut icon" href="assets/ico/favicon.ico">
<link href="offcanvas.css" rel="stylesheet">
<link href="css/select2.css" rel="stylesheet">
<link href="css/select2-bootstrap.css" rel="stylesheet">   
<script src="js/select2.min.js"></script>
<script src="js/select2_locale_th.js"></script>
<link rel = "stylesheet" href = "bootstrap-3.2.0-dist/css/bootstrap.min.css">
<script type="text/javascript" src="bootstrap-3.2.0-dist/js/jquery-1.9.0.js"></script>
<script type="text/javascript" src="bootstrap-3.2.0-dist/js/bootstrap.min.js"></script>
<script type="text/javascript" src="bootstrap-3.2.0-dist/js/jquery.min.js"></script>
<link rel="stylesheet" href="bootstrap.vertical-tabs.css">
<script src="js/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="js/function.js"></script>