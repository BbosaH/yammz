<?php
//require_once('Controllers/auth/auth.php');
//include('Controllers/like/like_functions.php');

?>

<head>
<!-- load jquery -->
<meta http-equiv="Content-Type" content="text/html" charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css.css">
<link rel = "stylesheet" href = "bootstrap-3.2.0-dist/css/bootstrap.min.css">
<link href="carousel.css" rel="stylesheet">
<link rel="icon" href="images/icons/yammz_logo.png">
<link href="offcanvas.css" rel="stylesheet">
<link href="css/select2.css" rel="stylesheet">
<link href="css/select2-bootstrap.css" rel="stylesheet">   
<!--<script src="js/select2.min.js"></script>
<script src="js/select2_locale_th.js"></script>-->

<script type="text/javascript" src="bootstrap-3.2.0-dist/js/jquery-1.9.0.js"></script>
<script type="text/javascript" src="bootstrap-3.2.0-dist/js/bootstrap.min.js"></script>
<script type="text/javascript" src="bootstrap-3.2.0-dist/js/jquery.min.js"></script>
<link rel="stylesheet" href="styles.css">



	<!--  ionicons-->
<link rel="stylesheet" href="ionicons-2.0.1/css/ionicons.min.css" media="all" type="text/css"/>
	<!--  ionicons-->
<link rel="stylesheet" href="Rating/css/star-rating.css" media="all" type="text/css"/>
<link rel="stylesheet" href="Rating/css/theme-krajee-fa.css" media="all" type="text/css"/>
<link rel="stylesheet" href="Rating/css/theme-krajee-svg.css" media="all" type="text/css"/>
<link rel="stylesheet" href="Rating/css/theme-krajee-uni.css" media="all" type="text/css"/>
<link rel="stylesheet" href="distjpicker/styles.css" />

 <link rel="stylesheet" href="node_modules/ng-dialog/css/myth/ngDialog.css" />
 <link rel="stylesheet" href="node_modules/ng-dialog/css/myth/ngDialog-theme-default.css" />
</head>

