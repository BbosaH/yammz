
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <title>Yammz it</title>
        <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"> 
    </head>
    <body>
        <div id="add"></div>
        <div id="container">
           
        <br/>
            <div id="reg_form">
                <iframe src='http://localhost:89/yammzit/Yammz/facebookplugin/registration.php?
                        client_id=1697629560489831&
                        redirect_uri=http://localhost:89/yammzit/Yammz/facebookplugin/store_user_data.php&
                        fields=[
                        {"name":"name"},
                        {"name":"email"},
                        {"name":"password"},
                        {"name":"gender"},
                        {"name":"birthday"},
                        {"name":"phone", "description":"Phone Number", "type":"text"}
                        ]'
                        scrolling="auto"
                        frameborder="no"
                        style="border:none"
                        allowTransparency="true"
                        width="500"
                        height="600">
                </iframe>
            </div>
        </div>
    </body>
</html>

