<style>
							
	.btn:focus, .btn:active:focus, .btn.active:focus {
		outline: 0 none;
	}

	.btn-primary {
		background: white;
		color:black;
		border-color:#C1C4C9;
	}
	.btn-primary:hover, .btn-primary:focus, .btn-primary:active, .btn-primary.active, .open > .dropdown-toggle.btn-primary {
		background: white;
		color:black;
	}
	.btn-primary:active, .btn-primary.active {
		background: #BD2532;
		box-shadow: none;
	}
</style>
<div class="panel panel-default">
	<div class="panel-heading">
		<span style="font-size:18px;" class="redbright">Cafe Javas. Hot Drinks</span>
	</div>
	<div class="panel-body">
		<div style="height:10px;"></div>
		<div class="col-lg-8 col-sm-8 col-xsm-8 col-xlg-8 col-md-8">
			<div class="panel panel-default" style="border-radius:0px;background-color:#EBEAEF;">
				<div class="panel-body">
					<div class="panel panel-default" style="height:550px;border-radius:0px;background-color:white;margin-left:-4px;margin-top:-4px;margin-right:-4px;margin-bottom:-4px;">
						<div class="panel-body">
							<div class="row">
								<div class="col-lg-2 col-sm-2 col-md-2 col-xs-2 ">
									<img src="images/profiles/right hand side 1.png" class="img-circle" style="width:50px;height:50px"  alt="Generic placeholder thumbnail">
								</div>
								<div class="col-lg-8 col-sm-8 col-md-8 col-xs-8 ">
									<span style="margin-left:-20px;">
										Yammz.com LTD
										<p style="margin-left:-20px;" class="grey">Sponsored</p>
									</span>
								</div>
								<div class="col-lg-2 col-sm-2 col-md-2 col-xs-2 " style="padding-left:5px;" >
									<span class="pull-right" style="padding-top:10px;margin-right:6px;">					
									  &nbsp; <span style="font-size:16px; color:#ECCB37" class="icon icon-add182"></span>
									  <span style="font-size:10;color:#7D7D7D;"><br/>Follow</span>					
									</span>	
								</div>
								
							</div>
							<div class="row">
								<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12 ">
								
									<h6 style="padding-left:10px;">
										Short description : Dress to kill with yammz.com's new fashion brand, 20% off all sales
									</h6>
									<img src="images/profiles/side ad size.png" width="430px" height="360px" alt="Responsive image" />
									<h3></h3>
								</div>	
							</div>
							
							<span href="" style="backgroung-color:#ACAEAE;font-weight:bold;font-size:16;" class="pull-left" >Best Place in Town </span>
							<span href="" style="backgroung-color:#F0F0F0;height:30px;color:black; margin-right:6px;padding-top:10px;" class="badge badge-background pull-right" >View Profile </span>
						
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-lg-4 col-sm-4 col-xsm-4 col-xlg-4 col-md-4">
			<span style="backgroung-color:#F0F0F0;color:black; margin-right:6px;border-radius:0px;width:100%;height:6%; padding-top:8px;font-size:16px;" class="badge badge-background" >Location </span>
			<table style="margin-left:10px;margin-top:25px;">
				<tr>
					<td style="font-weight:bold;width:100px;">Country</td><td  style="color:#A6A8B4;font-size:14px;">Uganda</td>
				</tr>
				<tr><td colspan="2"><div style="height:13px;"></div></td></tr>
				<tr>
					<td style="font-weight:bold;width:100px;">City</td><td style="color:#A6A8B4;font-size:14px;">Kampala</td>
				</tr>
				
			</table>
			<span style="backgroung-color:#F0F0F0;color:black; margin-right:6px;border-radius:0px;width:100%;height:6%; padding-top:8px;font-size:16px;margin-top:30px;" class="badge badge-background" >Date</span>
			<table style="margin-left:10px;margin-top:15px;">
				<tr>
					<td style="font-weight:bold;width:100px;">Start</td><td  style="color:#A6A8B4;font-size:14px;">06 March 2016</td>
				</tr>
				<tr><td colspan="2"><div style="height:13px;"></div></td></tr>
				<tr>
					<td style="font-weight:bold;width:100px;">End</td><td style="color:#A6A8B4;font-size:14px;">31 March 2016</td>
				</tr>
				
			</table>
			<span style="backgroung-color:#F0F0F0;color:black; margin-right:6px;border-radius:0px;width:100%;height:6%; padding-top:8px;font-size:16px;margin-top:30px;" class="badge badge-background" >Devise </span>
			<img src="images/ads/Search Ad.png" style="margin-left:60px;margin-top:20px;width:140px; height:100px;">
			<span style="backgroung-color:#F0F0F0;color:black; margin-right:6px;border-radius:0px;width:100%;height:6%; padding-top:8px;font-size:16px;margin-top:25px;" class="badge badge-background" >Category </span>
			<table style="margin-left:10px;margin-top:15px;">
				<tr>
					<td style="font-weight:bold;width:100px;">Category: &nbsp;</td><td  style="color:#A6A8B4;font-size:14px;">Nightlife</td>
				</tr>
				<tr><td colspan="2"><div style="height:13px;"></div></td></tr>
				<tr>
					<td style="font-weight:bold;width:100px;">Subcategory:</td><td style="color:#A6A8B4;font-size:14px;"> &nbsp;Bar</td>
				</tr>
				
			</table>
		</div>
		<div class="row">
			<div class="col-lg-12 col-sm-12 col-xsm-12 col-xlg-12 col-md-12">
				<hr   style="height:6px;background-color:#EBEAEF;"></hr>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12 col-sm-12 col-xsm-12 col-xlg-12 col-md-12">
				<table style="margin-left:13px;">
					<tr >
						<td style="font-size:14px;font-weight:bold;"><span class="pull-right">Age</span></td>
						<td width="130px">
							<select id="age" name="age" class="form-control" style=" margin-left:30px;width:70px;border-radius:0;height:25px;padding-top:2px; border-color:#868686;">
								<option  value="">18</option>
								<option  value="">19</option>
								<option  value="">20</option>
								<option  value="">21</option>
								<option  value="">22</option>
								<option  value="">23</option>
								<option  value="">24</option>
							
							</select>
						</td>
						<td>
							<select id="age" name="age" class="form-control" style=" border-radius:0;width:70px;height:25px;padding-top:2px;margin-left:0px; border-color:#868686;">
								<option  value="">18</option>
								<option  value="">19</option>
								<option  value="">20</option>
								<option  value="">21</option>
								<option  value="">22</option>
								<option  value="">23</option>
								<option  value="" selected>24</option>
							
							</select>
						</td>
					</tr>
					<tr>
						<td style="font-size:14px;font-weight:bold;"><span class="pull-right">Gender</span></td>
						<td colspan="2" style="">
							
							<div style="margin-left:28px;border:1px;margin-top:15px;" class="btn-group" data-toggle="buttons">
								<label class="btn btn-primary" style="height:25px;padding-top:2px;">
									<input type="radio" class ="active" name="options" id="option1">All
								</label>
								<label class="btn btn-primary" style="height:25px;padding-top:2px;">
									<input type="radio" class ="active" name="options" id="option2"> Male
								</label>
								<label class="btn btn-primary" style="height:25px;padding-top:2px;">
									<input type="radio" name="options" id="option3"> Female
								</label>
							</div>
						</td>
						
					</tr>
					<tr>
						<td style="font-size:14px;font-weight:bold;"><span style="margin-top:15px;" class="pull-right">Caption</span></td>
						<td colspan="2">
							<textarea class="form-control" rows="3" id="caption" name="caption" style="margin-top:20px;background-color:#E9EAEE;margin-left:30px;resize:none;border:0px;height:40px;border-radius:0px;width:320px;" placeholder="Best Place in Town"></textarea>
						</td>
					</tr>
					<tr>
						<td style="font-size:14px;font-weight:bold;"><span style="margin-top:-40px;" class="pull-right">Description</span></td>
						<td colspan="2">
							<textarea class="form-control" rows="3" id="caption" name="caption" style="background-color:#EBEAEF;margin-top:20px;margin-left:30px;resize:none;border:0px;height:100px;border-radius:0px;width:600px;" 
							placeholder="Short description : Dress to kill with yammz.com's new fashion brand, 20% off all sales"></textarea>
							
						</td>
					</tr>
				</table>
				
				
				<table>							
						<tr>
							<td>
								<div style="height:75px;"></div>
								<button  type="submit" name="add_business" class="btn btn-default" style="height:50px;font-size: 25px;border:0px; width:200px; background-color:#BD2532; font-weight:bold;border-radius:10px;margin-left:250px;color:#EED1D5;" >Save</button>
							</td>
							<td>
								<div style="height:115px;"></div>
								<B>&nbsp;&nbsp;&nbsp;&nbsp;Cancel</B>
							</td>
							
						</tr>
						
				</table>
				<div style="height:60px;"></div>
			</div>
		</div>
	</div>
</div>