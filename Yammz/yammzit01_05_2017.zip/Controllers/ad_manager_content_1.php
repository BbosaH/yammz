<table class="table" id="myTable" style="background-color:white;">
  <tbody>
	<tr>
	  <td colspan="8">
		<span style="font-size:20px;margin-left:16px;" class="pull-left redbright">Yammz it</span>
		<span class="pull-right">
			<form action="" >									
				<button class="btn " type="submit" name="searching" style="border-radius:0;background-color:#BE2633;margin-right:10px;margin-bottom:-15px;">
					<table>
						<tr>
							<td><span style="color:white;font-size:12px;" class="icon icon-plus"></span></td>
							<td><span style="color:white;margin-left:5px;margin-left:5px;font-size:12px;">Create Ad</span></td>														
						</tr>
					</table>											
					
				</button>										
			<form>
		</span>
	  </td>
	</tr>
	<tr>
	  <td colspan="8">
		<form action="search.php" role="search"  method="post">
			<div class="input-group" style="width:200px;margin-left:17px;">
				<input type="text" name="search" id="search" class="form-control pull-left noborderStyle" placeholder="Search...." style="border-radius:0;border-color:#EBEAEF;" >
				  <span class="input-group-btn">
					<button class="btn " type="submit" name="searching"  style="border-radius:0;color:#BD2532;height:34px;">
						<span class="icon icon-magnifying-glass34"></span>
						
					</button>
				  </span>
			</div>
		</form>
	  </td>
	</tr>
	<tr>
	  <td></td>
	  <td></td>
	  <td></td>
	  <td style="font-weight:bold;font-size:14px;">Ads</td>
	  <td style="font-weight:bold;font-size:14px;">Status</td>
	  <td style="font-weight:bold;font-size:14px;">Country</td>
	  <td style="font-weight:bold;font-size:14px;">Published date</td>
	</tr>					  
  
	<tr>
	  <td></td>
	  <td></td>
	  <td><img src="images/icons/cornered_grey_icon.png" style="width:35px;height:35px;"/></td>
	  <td style="font-size:13px;">Share, Comment & businesses around your city</td>
	  <td style="font-size:13px;font-weight:bold;">Approved</td>
	  <td>
		<div><span style="font-size:13px;">Uganda</span></div>
		<div><span style="font-size:13px;color:#C6C6C6;">Kampala</span></div>
	  </td>
	  <td>
		<span style="font-size:13px;">31 January 2016 </span>
		<span style="font-size:13px;color:#C6C6C6;margin-left:15px;">at 12:00</span>
	  </td>
	</tr>
	<tr>
	  <td></td>
	  <td></td>
	  <td><img src="images/icons/cornered_grey_icon.png" style="width:35px;height:35px;"/></td>
	  <td style="font-size:13px;">Yammz it big discount</td>
	  <td style="font-size:13px;font-weight:bold;">pending</td>
	  <td>
		<div><span style="font-size:13px;">Kenya</span></div>
		<div><span style="font-size:13px;color:#C6C6C6;">Nairobi</span></div>
	  </td>
	  <td>
		<span style="font-size:13px;">06 March 2016 </span>
		<span style="font-size:13px;color:#C6C6C6;margin-left:15px;">at 18:00</span>
	  </td>
	</tr>
	<tr>
	  <td></td>
	  <td></td>
	  <td><img src="images/icons/cornered_grey_icon.png" style="width:35px;height:35px;"/></td>
	  <td style="font-size:13px;">Doctor's Plaza's Health Center</td>
	  <td style="font-size:13px;font-weight:bold;">Approved</td>
	  <td>
		<div><span style="font-size:13px;">South Africa</span></div>
		<div><span style="font-size:13px;color:#C6C6C6;">Cape Town</span></div>
	  </td>
	  <td>
		<span style="font-size:13px;">06 December 2016 </span>
		<span style="font-size:13px;color:#C6C6C6;margin-left:15px;">at 04:00</span>
	  </td>
	</tr>
	<tr>
	  <td></td>
	  <td></td>
	  <td><img src="images/icons/cornered_grey_icon.png" style="width:35px;height:35px;"/></td>
	  <td style="font-size:13px;">Share, Comment & businesses around your city</td>
	  <td style="font-size:13px;font-weight:bold;">Approved</td>
	  <td>
		<div><span style="font-size:13px;">Uganda</span></div>
		<div><span style="font-size:13px;color:#C6C6C6;">Kampala</span></div>
	  </td>
	  <td>
		<span style="font-size:13px;">31 January 2016 </span>
		<span style="font-size:13px;color:#C6C6C6;margin-left:15px;">at 12:00</span>
	  </td>
	</tr>
	<tr>
	  <td></td>
	  <td></td>
	  <td><img src="images/icons/cornered_grey_icon.png" style="width:35px;height:35px;"/></td>
	  <td style="font-size:13px;">Yammz it big discount</td>
	  <td style="font-size:13px;font-weight:bold;">pending</td>
	  <td>
		<div><span style="font-size:13px;">Kenya</span></div>
		<div><span style="font-size:13px;color:#C6C6C6;">Nairobi</span></div>
	  </td>
	  <td>
		<span style="font-size:13px;">06 March 2016 </span>
		<span style="font-size:13px;color:#C6C6C6;margin-left:15px;">at 18:00</span>
	  </td>
	</tr>
	<tr>
	  <td></td>
	  <td></td>
	  <td><img src="images/icons/cornered_grey_icon.png" style="width:35px;height:35px;"/></td>
	  <td style="font-size:13px;">Doctor's Plaza's Health Center</td>
	  <td style="font-size:13px;font-weight:bold;">Approved</td>
	  <td>
		<div><span style="font-size:13px;">South Africa</span></div>
		<div><span style="font-size:13px;color:#C6C6C6;">Cape Town</span></div>
	  </td>
	  <td>
		<span style="font-size:13px;">06 December 2016 </span>
		<span style="font-size:13px;color:#C6C6C6;margin-left:15px;">at 04:00</span>
	  </td>
	</tr>
	<tr>
	  <td></td>
	  <td></td>
	  <td><img src="images/icons/cornered_grey_icon.png" style="width:35px;height:35px;"/></td>
	  <td style="font-size:13px;">Share, Comment & businesses around your city</td>
	  <td style="font-size:13px;font-weight:bold;">Approved</td>
	  <td>
		<div><span style="font-size:13px;">Uganda</span></div>
		<div><span style="font-size:13px;color:#C6C6C6;">Kampala</span></div>
	  </td>
	  <td>
		<span style="font-size:13px;">31 January 2016 </span>
		<span style="font-size:13px;color:#C6C6C6;margin-left:15px;">at 12:00</span>
	  </td>
	</tr>
	<tr>
	  <td></td>
	  <td></td>
	  <td><img src="images/icons/cornered_grey_icon.png" style="width:35px;height:35px;"/></td>
	  <td style="font-size:13px;">Yammz it big discount</td>
	  <td style="font-size:13px;font-weight:bold;">pending</td>
	  <td>
		<div><span style="font-size:13px;">Kenya</span></div>
		<div><span style="font-size:13px;color:#C6C6C6;">Nairobi</span></div>
	  </td>
	  <td>
		<span style="font-size:13px;">06 March 2016 </span>
		<span style="font-size:13px;color:#C6C6C6;margin-left:15px;">at 18:00</span>
	  </td>
	</tr>
	<tr>
	  <td></td>
	  <td></td>
	  <td><img src="images/icons/cornered_grey_icon.png" style="width:35px;height:35px;"/></td>
	  <td style="font-size:13px;">Doctor's Plaza's Health Center</td>
	  <td style="font-size:13px;font-weight:bold;">Approved</td>
	  <td>
		<div><span style="font-size:13px;">South Africa</span></div>
		<div><span style="font-size:13px;color:#C6C6C6;">Cape Town</span></div>
	  </td>
	  <td>
		<span style="font-size:13px;">06 December 2016 </span>
		<span style="font-size:13px;color:#C6C6C6;margin-left:15px;">at 04:00</span>
	  </td>
	</tr>
	<tr>
	  <td></td>
	  <td></td>
	  <td><img src="images/icons/cornered_grey_icon.png" style="width:35px;height:35px;"/></td>
	  <td style="font-size:13px;">Share, Comment & businesses around your city</td>
	  <td style="font-size:13px;font-weight:bold;">Approved</td>
	  <td>
		<div><span style="font-size:13px;">Uganda</span></div>
		<div><span style="font-size:13px;color:#C6C6C6;">Kampala</span></div>
	  </td>
	  <td>
		<span style="font-size:13px;">31 January 2016 </span>
		<span style="font-size:13px;color:#C6C6C6;padding-left:10px;">at 12:00</span>
	  </td>
	</tr>
	<tr>
	  <td></td>
	  <td></td>
	  <td><img src="images/icons/cornered_grey_icon.png" style="width:35px;height:35px;"/></td>
	  <td style="font-size:13px;">Yammz it big discount</td>
	  <td style="font-size:13px;font-weight:bold;">pending</td>
	  <td>
		<div><span style="font-size:13px;">Kenya</span></div>
		<div><span style="font-size:13px;color:#C6C6C6;">Nairobi</span></div>
	  </td>
	  <td>
		<span style="font-size:13px;width:20px;">06 September 2016 </span>
		<span style="font-size:13px;color:#C6C6C6;margin-left:10px;">at 18:00</span>
	  </td>
	</tr>
	<tr>
	  <td></td>
	  <td></td>
	  <td><img src="images/icons/cornered_grey_icon.png" style="width:35px;height:35px;"/></td>
	  <td style="font-size:13px;">Doctor's Plaza's Health Center</td>
	  <td style="font-size:13px;font-weight:bold;">Approved</td>
	  <td>
		<div><span style="font-size:13px;">South Africa</span></div>
		<div><span style="font-size:13px;color:#C6C6C6;">Cape Town</span></div>
	  </td>
	  <td>
		
		<span style="font-size:13px;width:20px;">06 December 2016 </span>
		<span style="font-size:13px;color:#C6C6C6;padding-left:10px;">at 04:00</span>
	  </td>
	</tr>
  </tbody>
</table>