<p><B>EVENTS AT CAFE JAVAS</B></P>
<div class="row">
	<div class="col-lg-3 col-sm-3 col-md-3 col-xs-3">
		
		 <img src="images/profiles/right hand side 1.png" width="60px" height="80px">  
		
	</div>
	<div class="col-lg-9 col-sm-9 col-md-9 col-xs-9">
		 <div class="caption">
			<p class="redbright">Kcca Kampala festive 2016</p>
			<h6>On Friday,0ct 16, 6:00pm - Saturday, Oct 17, 11:00pm</h6>	
			<h6>46 Interested</h6>										
		</div> 
	</div>
</div>
<h2></h2>
<div class="row">
	<div class="col-lg-3 col-sm-3 col-md-3 col-xs-3">
		<img src="images/profiles/right hand side 2.png" width="60px" height="80px">
	</div>
	<div class="col-lg-9 col-sm-9 col-md-9 col-xs-9">
		 <div class="caption">
			<p class="redbright">Kcca Kampala festive 2016</p>
			<h6>On Friday,0ct 16, 6:00pm - Saturday, Oct 17, 11:00pm</h6>	
			<h6>46 Interested</h6>										
		</div> 
	</div>
</div>
<h6 > <a class="redbright">view All</a></h6>