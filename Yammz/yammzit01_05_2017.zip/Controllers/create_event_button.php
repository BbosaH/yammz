<div class="panel panel-default noborderStyle">					
	<div class="panel-body"style="padding-left:30px;">
		
		<a type="button" href="create_event.php" class="btn btn-default btn-block btn-primary"  style="background-color:#BE2633; border-radius:10px; border-color:#BE2633; height:70px; width:280px">
			<span ><img src="images/icons/create_event.png" width="70px"/></span>&nbsp;&nbsp;
			<span style="font-size:18px; color:#E5DDDD;"><B>Create Event</B> </span>
		</a>
		
	</div>
</div>