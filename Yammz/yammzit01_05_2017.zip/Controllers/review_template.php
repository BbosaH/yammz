<!--begin of comment area-->
					 <table>
					 `<!--first table row-->
					 	<tr>
							    <td style="vertical-align:top;" width="10px;">

									<img src="images/icons/2.png" class="img-circle" style="width:50px;height:50px"  alt="Generic placeholder thumbnail">
								</td>
								<td >
														
									<span >
									<h6><B><a style="text-decoration:none;" href="" class="black">&nbsp;
															
										<?php echo"henry"; ?>
															
									</a></B> Wrote a review on <B><a href="business_page_3.php?bd=<?php echo"$bid"; ?>" style="text-decoration:none;" class="black">Cafe Javas</a></B>				
										<span class="help-block " style="color:#CFCFCF;">&nbsp;&nbsp; 20/22/2016 &nbsp; 3hrs ago</span>
										<h6></h6>
															
											<div ng-include="'Controllers/rate_pricing.php'" scope="" onload="">  </div>
										
									</span>

								</td>

													
						</tr>
					<!--second table row-->
						<tr>
						<td  style="vertical-align:top;" width="10px;">
							<h6 >
								<p >
										
								</p>						
														

						</td>
						<td  >
							<h6 >
								<p style="width: 355px;">
									henry bbos lujja is from mars he returned following thor vthe greek God who also followed lokie his brother henry bbos lujja is from mars he returned following thor vthe greek God who also followed lokie his brother henry bbos lujja is from mars he returned following thor vthe greek God who also followed lokie his brother henry bbos lujja is from mars he returned following thor vthe greek God who also followed lokie his brother henry bbos lujja is from mars he returned following thor vthe greek God who also followed lokie his brother henry bbos lujja is from mars he returned following thor vthe greek God who also followed lokie his brother	
								</p>						
									
							</h6>					

						</td>
							
						</tr>
					<!--third table row table row-->
					<tr>
						<td  style="vertical-align:top;" width="10px;">
							<h6 >
								<p >
										
								</p>						
														

						</td>
						<td  style="">
							<div style="height: 1px; width: 455px; background: rgb(233,234,238); margin-left: -45px;">
								
							</div>						

						</td>
							
						</tr>


					<!--fourth tablerow-->
					<tr>
						<td  style="vertical-align:top;" width="10px;">
							<h6 >
								<p >
										
								</p>						
														

						</td>
						<td  style="">
							<table>
																		<tr>
																		<td style="width:120px;">
																				
																					<a class=" btn simplegrey "style="text-decoration:none;"  data-toggle="collapse" data-target="#comment">
																						<span style="font-size:16px;" class="glyphicon glyphicon-thumbs-up"></span>&nbsp;&nbsp;Like
																					</a>
																				
																			
																			</td>
																			
																			<td style="width:140px;">
																				
																					<a class=" btn simplegrey "style="text-decoration:none;"  data-toggle="collapse" data-target="#comment">
																						<span style="font-size:16px;" class="glyphicon glyphicon-comment pull-left"></span>&nbsp;&nbsp;Comment
																					</a>
																				
																			
																			</td>
																			<td>
																				<?php require_once("../share_model.php"); ?>
																									
																					<a class="simplegrey btn " style="text-decoration:none;" data-toggle="modal" data-target="#mdl_example">
																					<span class="glyphicon glyphicon-share pull-left"></span>&nbsp;&nbsp; Share
																					</a>
																				
																				
																			</td>
																		</tr>
																	</table>		

						</td>
							
						</tr>

					<!--foutth table row table row-->
						<tr>
						<td  style="vertical-align:top;" width="10px;">
							<h6 >
								<p >
										
								</p>						
														

						</td>
						<td  style="">
							<form class=" noborderStyle" role="form" action="Controllers/post_comment.php" method="post" >
									<div class="form-group"> 
																	
										<input type="hidden" name="review_id" id="review_id" value=""/>
										<input type="hidden" name="up" id="up" value=""/>
										<input type="hidden" name="redir" id="redir" value=""/>
																		
																	
										<table>
											<tr>
												<td>
												
													<input type="text" name="content" id="content" class="form-control pull-left noborderStyle" style="border-radius:0; background-color:#E9EAEE;text-align:left; width:300px;height:30px; " placeholder="Write a comment..." >
					
																					
												</td>
												<td style="vertical-align:top;">
													<div style="width:65px;"></div><input type="submit" id="submit"  style="background-color:#E9EAEE;height:30px;text-align: center;line-height: 15px; width:60px;font-weight:bold;background-color:#BD2532; color:white;border-radius:10;" class=" form-control submit pull-right" value="Send" />
												</td>
											</tr>
										</table>
																	
									</div>
							</form>				
														

						</td>
							
						</tr>
						</table>

						<!--End of comment area-->