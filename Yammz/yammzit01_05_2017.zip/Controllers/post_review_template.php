<!--begin of comment area-->
					 <table>
					 `<!--first table row-->
					 	<tr>
							    <td style="vertical-align:top;" width="10px;">

									<img src="images/icons/2.png" class="img-circle" style="width:50px;height:50px"  alt="Generic placeholder thumbnail">
								</td>
								<td >
														
									<span >
									<h6><B><a style="text-decoration:none;" href="" class="black">&nbsp;
															
										<?php echo"Cafe javas"; ?>
															
									</a></B>            <B><a href="business_page_3.php?bd=<?php echo"$bid"; ?>" style="text-decoration:none;" class="black"></a></B>				
										<span class="help-block " style="color:#CFCFCF;">&nbsp;&nbsp; Bukoto &nbsp; Kampala</span>
										<h6></h6>
															
											<div ng-include="'Controllers/rate_pricing.php'" scope="" onload="">  </div>
										
									</span>

								</td>

													
						</tr>
					<!--second table row-->
						<tr>
						<td  style="vertical-align:top;" width="10px;">
							<h6 >
								<p >
										
								</p>						
														

						</td>
						<td  >
							<h6 >
								<p style="width: 355px;">
									Rate business &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; price business
								</p>						
									
							</h6>					

						</td>
							
						</tr>
					<!--third table row -->
					   <td  style="vertical-align:top;" width="00px;">
							<h6 >
								<p >
										
								</p>						
														

						</td>
						<td  >
						<textarea class="form-control pull-left noborderStyle" style="border-radius:0; background-color:#E9EAEE;text-align:left; width: 455px; height:100px; margin-left: -45px;" placeholder="write a review .....">
						
						</textarea>

						<!--<input type="text" name="content" id="content" class="form-control pull-left noborderStyle" style="border-radius:0; background-color:#E9EAEE;text-align:left; width:455px;height:100px; margin-left: -45px;" placeholder="Write a comment..." >-->
										

						</td>


					<!--third table row table row-->
					<tr>
						<td  style="vertical-align:top;" width="10px;">
							<h6 >
								<p >
										
								</p>						
														

						</td>
						<td  style="">
							<div style="height: 1px; width: 455px; background: rgb(233,234,238); margin-left: -45px;">
								
							</div>					

						</td>
							
						</tr>


					<!--fourth tablerow-->
					<!--second table row-->
						<tr>
						<td  style="vertical-align:top;" >
							<h6 >
								<p >
									
								</p>						
														

						</td>
						<td  >
							<h6 >
								<p style="width: 355px; margin-left: -45px;">
									Have you been to this place before?	What was your experience
									
								</p>						
									
							</h6>					

						</td>
							
						</tr>

					
						</table>

						<!--End of comment area-->