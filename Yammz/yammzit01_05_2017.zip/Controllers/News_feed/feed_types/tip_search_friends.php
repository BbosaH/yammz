<!-- Start of Search for friend welcome feed -->

	<div class="panel-body">
		<!-- Start row with the right most three dots -->
		<div class="row">
			<div class="col-md-10 col-lg-10 col-sm-10 col-xl-10 col-xs-10"></div>
			<div class="col-md-2 col-lg-2 col-sm-2 col-xl-2 col-xs-2">
				<span style="" class="icon icon-three-dots-more-indicator three_dots pull-right"></span>
			</div>
		</div>
		<!-- End of row with the right most three dots -->

		<!-- Start of row with the Tips profile photo,name,date, Search note and Searching field -->
		<div class="row">
			<!-- column with Tip avatar -->
			<div class="col-md-2 col-lg-2 col-sm-2 col-xl-2 col-xs-2 right_space">
				<img class="img_profile" ng-src="{{BaseImageURL}}uploads/Tip_logo.png">
			</div>
			<!-- End of column with Tip avatar -->
			<!-- Start of column with Tip profile photo,name,date, Tip note and searching field -->
			<div class="col-md-10 col-lg-10 col-sm-10 col-xl-10 col-xs-10 profile_name_section_left">

				<h6>
					<span class="profile_name">Tips</span><br/>
					<span class="help-block " style="color:#CFCFCF;">06/06/2016 3hrs ago</span>
				</h6>
				<div class="welcome_notice">Search for friends on Yammzit using email</div>
				 <div class="welcome_notice" style="margin-left:20%;margin-top:0px;">Address and Names</div>
						
				<!-- start of Row with Search field -->
				<div style="margin-top:18px;"></div>
				<div class="row">
					<div class="col-md-10 col-lg-10 col-sm-10 col-xl-10 col-xs-10">

						<form action="" >
							<table>
								<tr>

								<td>
							
								<input type="text" class="form-control" style="border:none; border-radius:0px; height:30px;  width:250px;background-color:#EBEAEF;"  ng-minlength=4 ng-maxlength=50 placeholder="Search for friends...">
								</td><td>
								<button class="search_button" style="height:30px;width:100px;">Search</button>
								</td>
							
								</tr>
							</table>
							
						</form>

					</div>
					<div class="col-md-2 col-lg-2 col-sm-2 col-xl-2 col-xs-2 search_button_column">
						
					</div>
				</div>
				
				<!-- End of Row with Search field -->
			</div>
			<!-- End of column with Tip profile photo,date, Tip note Searching field -->
		</div>
		<!-- End of row with the user profile photo,name,date, welcome note ,like,commentss nd commenting -->
	</div>

<!-- End of Search for friend welcome feed -->