<!-- BY Wilson New Code for un reviewed business page -->
<div class="panel panel-default" style="min-height:290%">
		<div panel-body>
			<div >
				<img ng-src="{{BaseImageURL}}uploads/sad_emoji.jpg" style="width:150px;height:150px;margin-left:35%;margin-top:20%">
			</div>
			<div style="margin-left:44%;color:#999999;">No Reviews</div>
			<div style="margin-left:30%;margin-top:20px;color:#B4B4B4;">Be the first to write a review</div>
			<div style="margin-left:40%;color:#B4B4B4;">on the business</div>
		</div>
</div>
<!--End of code BY Wilson for un reviewed business page -->