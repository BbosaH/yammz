<div class="row" style="margin-top:2px;height:273%;">
	<div >
		<img ng-src="{{BaseImageURL}}uploads/sad_emoji.jpg" style="width:150px;height:150px;margin-left:37%;margin-top:15%">
	</div>
	<div style="margin-left:41%;color:#999999;">No Favourites</div>
	<div style="margin-left:25.5%;margin-top:20px;color:#B4B4B4;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Search for businesses you like and Add them </div>
	<div style="margin-left:35%;color:#B4B4B4;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;to your Favourite list </div>
	
		
</div>
