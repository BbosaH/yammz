<!-- <?php

	//function getPillContent($id,$category){

?> -->

		<div class="col-lg-4 col-sm-4 col-md-4 col-xs-4" >
			{{category.categoryname}}
		</div>
		<!-- <div class="col-lg-4 col-sm-4 col-md-4 col-xs-4" >
			<table>
				<tr>
				<td><span style="font-size:80px;color:#BD2532;" class="icon icon-meal2"></span></td>
				<td>
				<span style="height:20px;"></span>
				<span class="redbright" style="font-size:14px;font-weight:bold;margin-bottom:20px;vertical-align:bottom"><br/><br/><br/>&nbsp;&nbsp;&nbsp;<label class="control-label">Restaurant</label></span></td>
				</tr>
			</table>
	 </div> -->




<!-- <?php
	//}

?> -->
