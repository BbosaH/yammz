﻿<nav class="navbar navbar-default navbar-fixed-top" style="background-color:#BD2532" role="navigation">
	<div class="container">
		<div class="navbar-header" style="color:white;font-size:30px; padding-top:20px;">
			<button type="button" class="navbar-toggle"
					data-toggle="collapse"
					data-target="#bs-example-navbar-collapse-1">
		  <span class="sr-only">
			Toggle navigation
		  </span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			 <span style="color:white;font-size:30px; ">
				&nbsp; <B>Yammz it </B><img src="images/icons/yammz_logo.png" width="35" height="35" />&nbsp;&nbsp;&nbsp;&nbsp;
			  </span>
		</div>
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="padding-top:20px;"">
			
			<form class="navbar-form navbar-left"  role="search">
				<div class="input-group" style="width:250%">
					<input type="text" class="form-control pull-left noborderStyle" >
					  <span class="input-group-btn">
						<button class="btn " type="button">
							<span class="glyphicon glyphicon-search"></span>
							Search
						</button>
					  </span>
				</div>
			</form>
			<ul class="nav navbar-nav navbar-right">
				<li><a href="#" style="color:white;">Home</a></li>
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown"  style="color:white;">Uganda
						<b class="caret"></b>
					</a>
					<ul class="dropdown-menu">
						<li><a href="#">Kenya</a></li>
						<li><a href="#">Tanzania</a></li>
						<li><a href="#">Burundi</a></li>
						<li class="divider"></li>
						<li><a href="#">South Africa</a></li>
					</ul>
				</li>
				<li><a href="#"  style="color:white;"><img src="images/icons/notify.png" width="13" height="13px">Notifications</a></li>
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown"  style="color:white;">
					<img src="images/icons/network60.png" width="13" height="13px">Profile
						<b class="caret"></b>
					</a>
					<ul class="dropdown-menu">
						<li>
							<a href="user_profile.php"><i class="fa fa-fw fa-user"></i> My Profile</a>
						</li>
						<li>
							<a href="#"><i class="fa fa-fw fa-envelope"></i>My inbox</a>
						</li>
						<li>
							<a href="#"><i class="fa fa-fw fa-gear"></i>Change password</a>
						</li>
						<li class="divider"></li>
						<li>
							<a href="#"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
						</li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
	<h5></h5>
</nav>