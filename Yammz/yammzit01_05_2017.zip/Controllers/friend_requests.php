<!-- <div class="col-lg-8 col-sm-8 col-md-8 col-xs-12"  > -->
						<table style="width:700px;background-color:white;">
							<tr >
								<td colspan="2" style="padding-left:45px;padding-top:15px;" class="redbright">FRIEND REQUESTS</td>
							</tr >
							<tr >
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14; padding-right:290px;">
									<span>
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
								</td>
							</tr>
							<tr style=" background-color:#E4D4D5; ">
								
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14;padding-right:290px;">
									<span >
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
									<br/>
								</td>
							</tr>
							<tr >
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14; padding-right:290px;">
									<span>
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
								</td>
							</tr>
							<tr >
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14; padding-right:290px;">
									<span>
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
								</td>
							</tr>
							<tr style=" background-color:#E4D4D5; ">
								
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14;padding-right:290px;">
									<span >
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
									<br/>
								</td>
							</tr>
							<tr style=" background-color:#E4D4D5; ">
								
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14;padding-right:290px;">
									<span >
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
									<br/>
								</td>
							</tr>
							<tr >
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14; padding-right:290px;">
									<span>
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
								</td>
							</tr>
							<tr >
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14; padding-right:290px;">
									<span>
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
								</td>
							</tr>
							<tr style=" background-color:#E4D4D5; ">
								
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14;padding-right:290px;">
									<span >
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
									<br/>
								</td>
							</tr>
							<tr >
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14; padding-right:290px;">
									<span>
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
								</td>
							</tr>
							<tr style=" background-color:#E4D4D5; ">
								
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14;padding-right:290px;">
									<span >
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
									<br/>
								</td>
							</tr>
							<tr >
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14; padding-right:290px;">
									<span>
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
								</td>
							</tr>
						
						</table>
<!-- </div> -->
					