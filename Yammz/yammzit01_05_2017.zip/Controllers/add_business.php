
<div class="panel panel-default noborderStyle">					
	<div class="panel-body"style="padding-left:40px;">
		&nbsp;
		
		<a type="button" href="add_business.php" class="btn btn-default btn-block btn-primary"  style="background-color:#BE2633; padding-top:15px; border-radius:10px; border-color:#BE2633; height:70px; width:280px">
			
			<table>
				<tr >
					<td style="padding-left:40px;">
						<span ><img src="images/icon_files_white/claim business icon.png" width="40px"/>&nbsp;&nbsp;</span>
					</td>
					<td>
						<div style="height:10px;"></div>
						<span  style=" color:white;"><B>Add Business</B> </span>
					</td>
				</tr>
			</table>
							
		</a>
		<h6></h6>
		<p style="margin-left:80px; font-weight:bold;">Do you work here?</p>
	</div>
</div>