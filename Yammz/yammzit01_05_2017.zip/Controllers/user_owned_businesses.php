<table >
	<tr>
		<td style="vertical-align:top;" width="10px;">


					<img ng-src="{{business.logo}}" style="border-radius:10px;" width="104px" height="104px" >


		</td>
		<td style="padding-left:10px; margin-top:5px; margin-bottom:5px;" >
			<div style="height:7px;"></div>
			

			<a class="redbright"  ng-href="{{BaseURL}}business_page_owners_view.php?current_business_id={{business.id}}" style="padding-top:15px; text-decoration:none;">
				{{business.name}}
			</a>

			<br/>
			<p class="grey" style="margin-top:5px;font-size:12;">
				{{business.address}}
			</p>
			<h6 class="grey">
				<img src="images/icons/star.png" width="10px" height="10px"/>
				<img src="images/icons/star.png" width="10px" height="10px"/>
				<img src="images/icons/star.png" width="10px" height="10px"/>
				<img src="images/icons/star.png" width="10px" height="10px"/>
				<img src="images/icons/star.png" width="10px" height="10px"/>

			</h6>
			<h6 style="padding-left:3px;" class="grey">
				<img src="images/icon_files_white/cash_green.png" width="7px" height="10px"/>&nbsp;
				<img src="images/icon_files_white/cash_green.png" width="7px" height="10px"/>&nbsp;
				<img src="images/icon_files_white/cash_green.png" width="7px" height="10px"/>&nbsp;
				<img src="images/icon_files_white/cash_green.png" width="7px" height="10px"/>&nbsp;
				<img src="images/icon_files_white/cash_green.png" width="7px" height="10px"/>

			</h6>

		</td>

	</tr>

</table>
<hr style="height:2px; background-color:#EBEAEF; margin-top:10px; margin-bottom:0px;"></hr>
