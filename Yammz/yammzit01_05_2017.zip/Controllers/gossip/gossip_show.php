<div class="panel panel-default" style="border:none; border-radius:0px"> 
	<div class="panel-body">
		<div class="row">
			<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
				<div class="tab-content">
					<div class="tab-pane active" id="allgossip">
						<?php require_once('Controllers/gossip/all_gossip.php');?>
					</div>
					<div class="tab-pane" id="mygossip">
						My gossip
					</div>
					<div class="tab-pane" id="events">
						Events content
					</div>
					<div class="tab-pane" id="food">
						Food information
					</div>
					<div class="tab-pane" id="shopping_products">
						Shopping and products
					</div>
					<div class="tab-pane" id="travel">
						Travel information
					</div>
					<div class="tab-pane" id="relationship_dating">
						Relationship and dating
					</div>
					<div class="tab-pane" id="humour_offbeat">
						Humour and offbeat
					</div>
					<div class="tab-pane" id="sports">
						Sports
					</div>
					<div class="tab-pane" id="entertainment_pop">
						Entertainment and pop
					</div>
					<div class="tab-pane" id="news_politics">
						News and politics
					</div>
					<div class="tab-pane" id="family_parenting">
						Family and parenting
					</div>
					<div class="tab-pane" id="yammzit_questions">
						Yamms-it questions
					</div>
					
				</div>
			</div>
		</div>
	</div>
</div>