<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12 img-responsive  business_profile_cover_photo " style="width:1135; height:390; padding-left:10px"> 
			<!-- <img src="images/icons/great_music.jpg" class="img-responsive" style="width:1123; height:370;" /> -->
			
		<div class="row" style="padding-top:220px;">
			<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
				<table>
					<tr >
						<td>
							<a class="btn" href="business_page_3.php" style="height:40px" >
								<span style="color:#FFFFFF;font-size:30px;">
									<B>												
										 <table>
											 <tr>
												<td><span style="color:#FFFFFF;font-size:30px;"><B>Cafe Javas</B></span></td>
												<td><div style="color:#901C25;font-size:31px;margin-left:10px; " class="icon icon-shield"></div></td>
											  </tr>
											 
    
										 </table>												 
									 </B>
								</span>
							</a>
						</td>
					</tr>
					<tr>
						<td>
							<a class="btn" href="business_page_3.php" >
								<span style="color:#FFFFFF;font-size:15px;padding-left:0px;">Acacia Avenu, Bukoto street<span>
							</a>
						</td>
					</tr>
				
				</table>
				<p style="padding-left:13px;color:#FFFFFF;"> Category: Restaurants > Cafe  &nbsp;&nbsp;&nbsp; Category: Food > Coffee & tea  &nbsp;&nbsp;&nbsp; Category: Restaurants > Cupcakes</p>
				<div class="row" style="padding-left:12px; ">
					<span>
						<a type="btn" style="background-color:#231E1A;width:77; color:#D0CCC9; border-color:grey;" class="btn btn-default noborderStyle ">
							<table style="background-color:#231E1A;">
								<tr>
									<td>
										<div style="font-size:20px;margin-left:15px;color:#D0CCC9;margin-top:1px;" class="icon icon-book86"></div>
										<div style="height:4px;"></div>
										<span style="font-size:11px;padding-bottom:0px;color:#D0CCC9">Favourites</span>
									</td>
								</tr>
							</table>						
						</a>
					</span>
					<span>
						<a type="btn" style="background-color:#231E1A;width:77px; color:#D0CCC9; border-color:grey;" class="btn btn-default noborderStyle ">
						
							<table style="background-color:#231E1A;">
								<tr>
									<td>
										<div style="font-size:20px;margin-left:15px;color:#D0CCC9;margin-top:1px;" class="icon icon-add182"></div>
										<div style="height:4px;"></div>
										<span style="font-size:11px;padding-bottom:0px;color:#D0CCC9;margin-left:10px;">Follow</span>
									</td>
								</tr>
							</table>	
							
						</a>
					</span>
					<span>
						<a type="btn" style="background-color:#231E1A;width:77; color:#D0CCC9; border-color:grey;" class="btn btn-default noborderStyle ">
							
							<table style="background-color:#231E1A;">
								<tr>
									<td>
										<div style="font-size:20px;margin-left:15px;color:#D0CCC9;margin-top:0px;" class="icon icon-download43"></div>
										<div style="height:4px;"></div>
										<span style="font-size:11px;padding-bottom:0px;color:#D0CCC9">Message</span>
									</td>
								</tr>
							</table>	
						</a>
					</span>
					<span>
						<a type="btn" style="background-color:#231E1A;width:77px; color:#D0CCC9; border-color:grey;" class="btn btn-default noborderStyle ">
							
							<table style="background-color:#231E1A;">
								<tr>
									<td>
										<div style="font-size:20px;margin-left:15px;color:#D0CCC9;margin-top:0px;" class="icon icon-medical109"></div>
										<div style="height:4px;"></div>
										<span style="font-size:11px;padding-bottom:0px;color:#D0CCC9">Add Photo</span>
									</td>
								</tr>
							</table>	
						</a>
					</span>
					<span>
						<a type="btn" style="background-color:#231E1A;width:77px; color:#D0CCC9; border-color:grey;" class="btn btn-default noborderStyle ">
							<div style="font-size:20px;margin-top:0px;" class="icon icon-carnival48"></div>
							<div style="height:4px;"></div>
							<span style="font-size:11px;">Events</span>
						</a>
					</span>
					<span>
						<a type="btn" style="background-color:#231E1A;width:77px; color:#D0CCC9; border-color:grey;" class="btn btn-default noborderStyle ">
							<div style="font-size:20px;margin-top:1px;" class="icon icon-sharing6"></div>
							<div style="height:4px;"></div>
							<span style="font-size:11px;">Share</span>
						</a>
					</span>
					
					<span>
						<button type="submit" style="background-color:#231E1A; height:54px; color:#D0CCC9; border-color:grey;" class="btn btn-default  noborderStyle">
							<table>
								<tr>
									<td><div style="height:13px; color:#D0CCC9;font-size:13;">Rate Business&nbsp;&nbsp;</div></td>
									<td>
										<img src="images/icons/star.png" width="18px" height="18px"/>
										<img src="images/icons/star.png" width="18px" height="18px"/>
										<img src="images/icons/star.png" width="18px" height="18px"/>
										<img src="images/icons/star.png" width="18px" height="18px"/>
										<img src="images/icons/starwhite.png" width="18px" height="18px"/>
									</td>
								</tr>
							</table>
							
						</button>
					</span>
					<span>
						<button type="submit" style="background-color:#231E1A; color:#D0CCC9; height:54px; border-color:grey;" class="btn btn-default noborderStyle">
						<div style="margin-top:3px;"></div>
						Price Rating &nbsp;
							
							<img src="images/icons/currency16.png" width="12px" height="15px"/>&nbsp;
							<img src="images/icons/currency16.png" width="12px" height="15px"/>&nbsp;
							<img src="images/icons/currency16.png" width="12px" height="15px"/>&nbsp;
							<img src="images/icons/currency16.png" width="12px" height="15px"/>&nbsp;
							<img src="images/icons/currencywhiteicon.png" width="12px" height="15px"/>
						</button>
					</span>														
				</div>
			</div>
		</div>
	</div>		
