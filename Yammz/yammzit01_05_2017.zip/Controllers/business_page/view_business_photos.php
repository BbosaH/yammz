
		<div class="panel-body">
			<div class="row" style="margin-top:2px;" >
				<div class="col-lg-3 col-sm-3 col-md-3 col-xs-12" style="margin-top:30px;" ng-repeat="photo in photo_names">
					<img ng-src="{{photo}}" width="170" height="150" style="border-radius: 5px;">
				</div>
				
			</div>
			<h1></h1>
			
	</div>