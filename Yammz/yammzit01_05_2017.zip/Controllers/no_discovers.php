<div class="row" style="margin-top:2px;height:273%;">
	<div >
		<img ng-src="{{BaseImageURL}}uploads/sad_emoji.jpg" style="width:150px;height:150px;margin-left:37%;margin-top:15%">
	</div>
	<div style="margin-left:41%;color:#999999;">No Discovers</div>
	<div style="margin-left:25.5%;margin-top:20px;color:#B4B4B4;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Share Cool,interesting Places you Discover </div>
	<div style="margin-left:32.9%;color:#B4B4B4;">with your Friends and Family</div>
	
	<a type="button" href="add_business.php" class="btn btn-default btn-block btn-primary"  style="background-color:#BE2633; padding-top:15px; border-radius:6px; border-color:#BE2633; height:30px; width:125px;margin-left:38%;margin-top:13px;">			
		<div class="col-md-2" style="margin-left:-20px;"><img src="images/icon_files_white/claim business icon.png" width="20px" style="margin-top:-10px;"/></div>
		<div class="col-md-2"><div  style=" color:white;font-size:12px;margin-top:-7px;"><B>Add Business</B> </div></div>									
	</a>	
</div>
