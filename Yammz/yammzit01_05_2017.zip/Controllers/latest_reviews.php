<div class="panel panel-default" style="border:none; border-radius:0px"> 
	<div class="panel-body">
		<div class="row">
			<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
				<table>
					<tr>
						<td style="vertical-align:top;" width="10px;">
							<img src="images/profiles/right hand side 1.png" class="img-circle" style="width:50px;height:50px"  alt="Generic placeholder thumbnail">
						</td>
						<td >
							
							<span >
							<h6><B><a href="user_profile.php" class="black">&nbsp; Steven Byamugisha</a></B> Made a review on <B><a href="business_page.php" class="black">Cafe Javas</a></B>				
							<span class="help-block " style="color:#CFCFCF;">&nbsp;&nbsp; 26/12/2015 &nbsp; 3hrs ago</span>
							</h6>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								&nbsp;&nbsp;
								<img src="images/icon_files_white/cash_green.png" width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<br/>
							</span>
						</td>
						
					</tr>
					<tr>
						<td colspan="2" style="padding-left:15px;">
							<h6 >
								<p>
									Responding to positive reviews should be easy, right? It does sound easy,
									but it's surprisingly easy to get this wrong .When contacting a positive reviewer,
									your purpose should be simply to deliver a human thank you and let them know you care
								</p>
								<hr></hr>
								<div class="row" style="color:grey; padding-left:10px;">
									<div class="col-lg-4 col-sm-4 col-md-4 col-xs-4  " >
										<h6>
											<a class=" simplegrey btn" data-toggle="collapse" data-target="#demo">
												<img src="images/icons/like85-3.png" width="13" height="13px">&nbsp;&nbsp;Like
											</a>
										</h6>
									</div>
									<div class="col-lg-4 col-sm-4 col-md-4 col-xs-4 ">
										<h6>
											<a class=" simplegrey btn" data-toggle="collapse" data-target="#comment">
												<span class="glyphicon glyphicon-comment pull-left"></span>&nbsp;&nbsp;Comment
											</a>
										</h6>
									</div>
									<div class="col-lg-4 col-sm-4 col-md-4 col-xs-4 ">
										<h6>					
											<a class="simplegrey btn "  data-toggle="modal" data-target="#mdl_example">
											<span class="glyphicon glyphicon-share pull-left"></span>&nbsp;&nbsp; Share
											</a>
										</h6>
										<?php require_once("share_model.php"); ?>
									</div>
								</div>
								<h6></h6>
								<form class="form-horizontal" role="form">
									 <div class="form-group"> 
										 <div class="col-lg-11 col-sm-11 col-md-11 col-xs-11" style=" padding-left:18px;">   
											<input class="form-control " style="background-color:#E9EAEE;" id="focusedInput" type="text" placeholder="Write a comment..."> 
										 </div> 
									 </div>
								</form>
							</h6>
						</td>
					</tr>
					
			</table>
			
			</div>
		</div>
	</div>
</div>
<div class="panel panel-default" style="border:none; border-radius:0px"> 
	<div class="panel-body">
		<div class="row">
			<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
				<table>
					<tr>
						<td style="vertical-align:top;" width="10px;">
							<img src="images/profiles/right hand side 1.png" class="img-circle" style="width:50px;height:50px"  alt="Generic placeholder thumbnail">
						</td>
						<td >
							
							<span >
							<h6><B><a href="user_profile.php" class="black">&nbsp; Steven Byamugisha</a></B> Made a review on <B><a href="business_page.php" class="black">Cafe Javas</a></B>				
							<span class="help-block " style="color:#CFCFCF;">&nbsp;&nbsp; 26/12/2015 &nbsp; 3hrs ago</span>
							</h6>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								&nbsp;&nbsp;
								<img src="images/icon_files_white/cash_green.png" width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<br/>
							</span>
						</td>
						
					</tr>
					<tr>
						<td colspan="2" style="padding-left:15px;">
							<h6 >
								<p>
									Responding to positive reviews should be easy, right? It does sound easy,
									but it's surprisingly easy to get this wrong .When contacting a positive reviewer,
									your purpose should be simply to deliver a human thank you and let them know you care
								</p>
								<hr></hr>
								<div class="row" style="color:grey; padding-left:10px;">
									<div class="col-lg-4 col-sm-4 col-md-4 col-xs-4  " >
										<h6>
											<a class=" simplegrey btn" data-toggle="collapse" data-target="#demo">
												<img src="images/icons/like85-3.png" width="13" height="13px">&nbsp;&nbsp;Like
											</a>
										</h6>
									</div>
									<div class="col-lg-4 col-sm-4 col-md-4 col-xs-4 ">
										<h6>
											<a class=" simplegrey btn" data-toggle="collapse" data-target="#comment">
												<span class="glyphicon glyphicon-comment pull-left"></span>&nbsp;&nbsp;Comment
											</a>
										</h6>
									</div>
									<div class="col-lg-4 col-sm-4 col-md-4 col-xs-4 ">
										<h6>					
											<a class="simplegrey btn "  data-toggle="modal" data-target="#mdl_example">
											<span class="glyphicon glyphicon-share pull-left"></span>&nbsp;&nbsp; Share
											</a>
										</h6>
										<?php require_once("share_model.php"); ?>
									</div>
								</div>
								<h6></h6>
								<form class="form-horizontal" role="form">
									 <div class="form-group"> 
										 <div class="col-lg-11 col-sm-11 col-md-11 col-xs-11" style=" padding-left:18px;">   
											<input class="form-control " style="background-color:#E9EAEE;" id="focusedInput" type="text" placeholder="Write a comment..."> 
										 </div> 
									 </div>
								</form>
							</h6>
						</td>
					</tr>
					
			</table>
			
			</div>
		</div>
	</div>
</div>
<div class="panel panel-default" style="border:none; border-radius:0px"> 
	<div class="panel-body">
		<div class="row">
			<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
				<table>
					<tr>
						<td style="vertical-align:top;" width="10px;">
							<img src="images/profiles/right hand side 1.png" class="img-circle" style="width:50px;height:50px"  alt="Generic placeholder thumbnail">
						</td>
						<td >
							
							<span >
							<h6><B><a href="user_profile.php" class="black">&nbsp; Steven Byamugisha</a></B> Made a review on <B><a href="business_page.php" class="black">Cafe Javas</a></B>				
							<span class="help-block " style="color:#CFCFCF;">&nbsp;&nbsp; 26/12/2015 &nbsp; 3hrs ago</span>
							</h6>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								&nbsp;&nbsp;
								<img src="images/icon_files_white/cash_green.png" width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<br/>
							</span>
						</td>
						
					</tr>
					<tr>
						<td colspan="2" style="padding-left:15px;">
							<h6 >
								<p>
									Responding to positive reviews should be easy, right? It does sound easy,
									but it's surprisingly easy to get this wrong .When contacting a positive reviewer,
									your purpose should be simply to deliver a human thank you and let them know you care
								</p>
								<img src="images/profiles/side ad size.png" class="img-responsive" width="400px" height="200px"/>
								<hr></hr>
								<div class="row" style="color:grey; padding-left:10px;">
									<div class="col-lg-4 col-sm-4 col-md-4 col-xs-4  " >
										<h6>
											<a class=" simplegrey btn" data-toggle="collapse" data-target="#demo">
												<img src="images/icons/like85-3.png" width="13" height="13px">&nbsp;&nbsp;Like
											</a>
										</h6>
									</div>
									<div class="col-lg-4 col-sm-4 col-md-4 col-xs-4 ">
										<h6>
											<a class=" simplegrey btn" data-toggle="collapse" data-target="#comment">
												<span class="glyphicon glyphicon-comment pull-left"></span>&nbsp;&nbsp;Comment
											</a>
										</h6>
									</div>
									<div class="col-lg-4 col-sm-4 col-md-4 col-xs-4 ">
										<h6>					
											<a class="simplegrey btn "  data-toggle="modal" data-target="#mdl_example">
											<span class="glyphicon glyphicon-share pull-left"></span>&nbsp;&nbsp; Share
											</a>
										</h6>
										<?php require_once("share_model.php"); ?>
									</div>
								</div>
								<h6></h6>
								<form class="form-horizontal" role="form">
									 <div class="form-group"> 
										 <div class="col-lg-11 col-sm-11 col-md-11 col-xs-11" style=" padding-left:18px;">   
											<input class="form-control " style="background-color:#E9EAEE;" id="focusedInput" type="text" placeholder="Write a comment..."> 
										 </div> 
									 </div>
								</form>
							</h6>
						</td>
					</tr>
					
			</table>
			
			</div>
		</div>
	</div>
</div>
<div class="panel panel-default" style="border:none; border-radius:0px"> 
	<div class="panel-body">
		<div class="row">
			<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
				<table>
					<tr>
						<td style="vertical-align:top;" width="10px;">
							<img src="images/profiles/right hand side 1.png" class="img-circle" style="width:50px;height:50px"  alt="Generic placeholder thumbnail">
						</td>
						<td >
							
							<span >
							<h6><B><a href="user_profile.php" class="black">&nbsp; Steven Byamugisha</a></B> Made a review on <B><a href="business_page.php" class="black">Cafe Javas</a></B>				
							<span class="help-block " style="color:#CFCFCF;">&nbsp;&nbsp; 26/12/2015 &nbsp; 3hrs ago</span>
							</h6>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								&nbsp;&nbsp;
								<img src="images/icon_files_white/cash_green.png" width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<br/>
							</span>
						</td>
						
					</tr>
					<tr>
						<td colspan="2" style="padding-left:15px;">
							<h6 >
								<p>
									Responding to positive reviews should be easy, right? It does sound easy,
									but it's surprisingly easy to get this wrong .When contacting a positive reviewer,
									your purpose should be simply to deliver a human thank you and let them know you care
								</p>
								<hr></hr>
								<div class="row" style="color:grey; padding-left:10px;">
									<div class="col-lg-4 col-sm-4 col-md-4 col-xs-4  " >
										<h6>
											<a class=" simplegrey btn" data-toggle="collapse" data-target="#demo">
												<img src="images/icons/like85-3.png" width="13" height="13px">&nbsp;&nbsp;Like
											</a>
										</h6>
									</div>
									<div class="col-lg-4 col-sm-4 col-md-4 col-xs-4 ">
										<h6>
											<a class=" simplegrey btn" data-toggle="collapse" data-target="#comment">
												<span class="glyphicon glyphicon-comment pull-left"></span>&nbsp;&nbsp;Comment
											</a>
										</h6>
									</div>
									<div class="col-lg-4 col-sm-4 col-md-4 col-xs-4 ">
										<h6>					
											<a class="simplegrey btn "  data-toggle="modal" data-target="#mdl_example">
											<span class="glyphicon glyphicon-share pull-left"></span>&nbsp;&nbsp; Share
											</a>
										</h6>
										<?php require_once("share_model.php"); ?>
									</div>
								</div>
								<h6></h6>
								<form class="form-horizontal" role="form">
									 <div class="form-group"> 
										 <div class="col-lg-11 col-sm-11 col-md-11 col-xs-11" style=" padding-left:18px;">   
											<input class="form-control " style="background-color:#E9EAEE;" id="focusedInput" type="text" placeholder="Write a comment..."> 
										 </div> 
									 </div>
								</form>
							</h6>
						</td>
					</tr>
					
			</table>
			
			</div>
		</div>
	</div>
</div>
<div class="panel panel-default" style="border:none; border-radius:0px"> 
	<div class="panel-body">
		<div class="row">
			<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
				<table>
					<tr>
						<td style="vertical-align:top;" width="10px;">
							<img src="images/profiles/right hand side 1.png" class="img-circle" style="width:50px;height:50px"  alt="Generic placeholder thumbnail">
						</td>
						<td >
							
							<span >
							<h6><B><a href="user_profile.php" class="black">&nbsp; Steven Byamugisha</a></B> Made a review on <B><a href="business_page.php" class="black">Cafe Javas</a></B>				
							<span class="help-block " style="color:#CFCFCF;">&nbsp;&nbsp; 26/12/2015 &nbsp; 3hrs ago</span>
							</h6>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								&nbsp;&nbsp;
								<img src="images/icon_files_white/cash_green.png" width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<br/>
							</span>
						</td>
						
					</tr>
					<tr>
						<td colspan="2" style="padding-left:15px;">
							<h6 >
								<p>
									Responding to positive reviews should be easy, right? It does sound easy,
									but it's surprisingly easy to get this wrong .When contacting a positive reviewer,
									your purpose should be simply to deliver a human thank you and let them know you care
								</p>
								<hr></hr>
								<div class="row" style="color:grey; padding-left:10px;">
									<div class="col-lg-4 col-sm-4 col-md-4 col-xs-4  " >
										<h6>
											<a class=" simplegrey btn" data-toggle="collapse" data-target="#demo">
												<img src="images/icons/like85-3.png" width="13" height="13px">&nbsp;&nbsp;Like
											</a>
										</h6>
									</div>
									<div class="col-lg-4 col-sm-4 col-md-4 col-xs-4 ">
										<h6>
											<a class=" simplegrey btn" data-toggle="collapse" data-target="#comment">
												<span class="glyphicon glyphicon-comment pull-left"></span>&nbsp;&nbsp;Comment
											</a>
										</h6>
									</div>
									<div class="col-lg-4 col-sm-4 col-md-4 col-xs-4 ">
										<h6>					
											<a class="simplegrey btn "  data-toggle="modal" data-target="#mdl_example">
											<span class="glyphicon glyphicon-share pull-left"></span>&nbsp;&nbsp; Share
											</a>
										</h6>
										<?php require_once("share_model.php"); ?>
									</div>
								</div>
								<h6></h6>
								<form class="form-horizontal" role="form">
									 <div class="form-group"> 
										 <div class="col-lg-11 col-sm-11 col-md-11 col-xs-11" style=" padding-left:18px;">   
											<input class="form-control " style="background-color:#E9EAEE;" id="focusedInput" type="text" placeholder="Write a comment..."> 
										 </div> 
									 </div>
								</form>
							</h6>
						</td>
					</tr>
					
			</table>
			
			</div>
		</div>
	</div>
</div>
<div class="panel panel-default" style="border:none; border-radius:0px"> 
	<div class="panel-body">
		<div class="row">
			<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
				<table>
					<tr>
						<td style="vertical-align:top;" width="10px;">
							<img src="images/profiles/right hand side 1.png" class="img-circle" style="width:50px;height:50px"  alt="Generic placeholder thumbnail">
						</td>
						<td >
							
							<span >
							<h6><B><a href="user_profile.php" class="black">&nbsp; Steven Byamugisha</a></B> Made a review on <B><a href="business_page.php" class="black">Cafe Javas</a></B>				
							<span class="help-block " style="color:#CFCFCF;">&nbsp;&nbsp; 26/12/2015 &nbsp; 3hrs ago</span>
							</h6>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								<img src="images/icons/star.png" width="16px" height="16px"/>
								&nbsp;&nbsp;
								<img src="images/icon_files_white/cash_green.png" width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<img src="images/icon_files_white/cash_green.png"  width="10px" height="13px"/>
								<br/>
							</span>
						</td>
						
					</tr>
					<tr>
						<td colspan="2" style="padding-left:15px;">
							<h6 >
								<p>
									Responding to positive reviews should be easy, right? It does sound easy,
									but it's surprisingly easy to get this wrong .When contacting a positive reviewer,
									your purpose should be simply to deliver a human thank you and let them know you care
								</p>
								<img src="images/profiles/side ad size.png"  width="150px" height="220px"/>
								<hr></hr>
								<div class="row" style="color:grey; padding-left:10px;">
									<div class="col-lg-4 col-sm-4 col-md-4 col-xs-4  " >
										<h6>
											<a class=" simplegrey btn" data-toggle="collapse" data-target="#demo">
												<img src="images/icons/like85-3.png" width="13" height="13px">&nbsp;&nbsp;Like
											</a>
										</h6>
									</div>
									<div class="col-lg-4 col-sm-4 col-md-4 col-xs-4 ">
										<h6>
											<a class=" simplegrey btn" data-toggle="collapse" data-target="#comment">
												<span class="glyphicon glyphicon-comment pull-left"></span>&nbsp;&nbsp;Comment
											</a>
										</h6>
									</div>
									<div class="col-lg-4 col-sm-4 col-md-4 col-xs-4 ">
										<h6>					
											<a class="simplegrey btn "  data-toggle="modal" data-target="#mdl_example">
											<span class="glyphicon glyphicon-share pull-left"></span>&nbsp;&nbsp; Share
											</a>
										</h6>
										<?php require_once("share_model.php"); ?>
									</div>
								</div>
								<h6></h6>
								<form class="form-horizontal" role="form">
									 <div class="form-group"> 
										 <div class="col-lg-11 col-sm-11 col-md-11 col-xs-11" style=" padding-left:18px;">   
											<input class="form-control " style="background-color:#E9EAEE;" id="focusedInput" type="text" placeholder="Write a comment..."> 
										 </div> 
									 </div>
								</form>
							</h6>
						</td>
					</tr>
					
			</table>
			
			</div>
		</div>
	</div>
</div>