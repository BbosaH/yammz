<div class="row" style="margin-top:2px;height:273%;">
	<div >
		<img ng-src="{{BaseImageURL}}uploads/sad_emoji.jpg" style="width:150px;height:150px;margin-left:37%;margin-top:15%">
	</div>
	<div style="margin-left:41%;color:#999999;">No Events</div>
	
	
		
</div>