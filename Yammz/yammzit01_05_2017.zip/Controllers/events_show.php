<div class="panel panel-default" style="border:none; border-radius:0px"> 
	<div class="panel-body">
	
		<div class="row">
			<div class="col-lg-3 col-sm-3 col-md-3 col-xs-3">
				<a  class="btn" href="events2.php">
					<img src="images/profiles/right hand side 3.png" width="130px" height="150px">
				</a>
			</div>
			<div class="col-lg-9 col-sm-9 col-md-9 col-xs-9" >
				 <div class="caption">
					<span style="padding-left:2px;" ><a  class="btn" href="events2.php" ><B><span class="redbright">Kampala Hood Hunters</span></B></a></span>
					<h6 style="padding-left:15px;">Sundy, 20 December, 15:00- 17:00</h6>
					<h6 style="padding-left:16px;"><B>Lugogo show ground, Kampala, Uganda</B></h6>	
					<h6 style="padding-left:15px;padding-bottom:3px;">This musical revolves round a Primadon who feels marglinalised and no 
					longer appreciated thw industry. Just.....</h6>	
					<div class="row">
						<h6 style="padding-left:12px;">
						&nbsp; &nbsp; &nbsp; 1 interested
						<a class="black"  style="padding-left:85px; ">
							<span style="color:#BCBCBC;font-size:12;">Posted By</span >  
							<img src="images/icons/great_music.jpg" class="img-circle" style="width:25px;height:25px">
							<B><span style="color:#626262;">Steven Byamugisha 11</span></B>
						</a>
						</h6>
					</div>
					
						
					
				</div> 
			</div>
		</div>
			
	</div>
</div>
<div class="panel panel-default" style="border:none; border-radius:0px"> 
	<div class="panel-body">
	
		<div class="row">
			<div class="col-lg-3 col-sm-3 col-md-3 col-xs-3">
				<a  class="btn" href="events2.php">
					<img src="images/profiles/right hand side 3.png" width="130px" height="150px">
				</a>
			</div>
			<div class="col-lg-9 col-sm-9 col-md-9 col-xs-9" >
				 <div class="caption">
					<span style="padding-left:2px;" ><a  class="btn" href="events2.php" ><B><span class="redbright">Kampala Hood Hunters</span></B></a></span>
					<h6 style="padding-left:15px;">Sundy, 20 December, 15:00- 17:00</h6>
					<h6 style="padding-left:16px;"><B>Lugogo show ground, Kampala, Uganda</B></h6>	
					<h6 style="padding-left:15px;padding-bottom:3px;">This musical revolves round a Primadon who feels marglinalised and no 
					longer appreciated thw industry. Just.....</h6>	
					<div class="row">
						<h6 style="padding-left:12px;">
						&nbsp; &nbsp; &nbsp; 1 interested
						<a class="black"  style="padding-left:85px; ">
							<span style="color:#BCBCBC;font-size:12;">Posted By</span >  
							<img src="images/icons/great_music.jpg" class="img-circle" style="width:25px;height:25px">
							<B><span style="color:#626262;">Steven Byamugisha 11</span></B>
						</a>
						</h6>
					</div>
					
					
						
					
				</div> 
			</div>
		</div>
			
	</div>
</div>
<div class="panel panel-default" style="border:none; border-radius:0px"> 
	<div class="panel-body">
	
		<div class="row">
			<div class="col-lg-3 col-sm-3 col-md-3 col-xs-3">
				<a  class="btn" href="events2.php">
					<img src="images/profiles/right hand side 3.png" width="130px" height="150px">
				</a>
			</div>
			<div class="col-lg-9 col-sm-9 col-md-9 col-xs-9" >
				 <div class="caption">
					<span style="padding-left:2px;" ><a  class="btn" href="events2.php" ><B><span class="redbright">Kampala Hood Hunters</span></B></a></span>
					<h6 style="padding-left:15px;">Sundy, 20 December, 15:00- 17:00</h6>
					<h6 style="padding-left:16px;"><B>Lugogo show ground, Kampala, Uganda</B></h6>	
					<h6 style="padding-left:15px;padding-bottom:3px;">This musical revolves round a Primadon who feels marglinalised and no 
					longer appreciated thw industry. Just.....</h6>	
					<div class="row">
						<h6 style="padding-left:12px;">
						&nbsp; &nbsp; &nbsp; 1 interested
						<a class="black"  style="padding-left:85px; ">
							<span style="color:#BCBCBC;font-size:12;">Posted By</span >  
							<img src="images/icons/great_music.jpg" class="img-circle" style="width:25px;height:25px">
							<B><span style="color:#626262;">Steven Byamugisha 11</span></B>
						</a>
						</h6>
					</div>
					
					
						
					
				</div> 
			</div>
		</div>
	</div>
</div>
<div class="panel panel-default" style="border:none; border-radius:0px"> 
	<div class="panel-body">
	
		<div class="row">
			<div class="col-lg-3 col-sm-3 col-md-3 col-xs-3">
				<a  class="btn" href="events2.php">
					<img src="images/profiles/right hand side 3.png" width="130px" height="150px">
				</a>
			</div>
			<div class="col-lg-9 col-sm-9 col-md-9 col-xs-9" >
				 <div class="caption">
					<span style="padding-left:2px;" ><a  class="btn" href="events2.php" ><B><span class="redbright">Kampala Hood Hunters</span></B></a></span>
					<h6 style="padding-left:15px;">Sundy, 20 December, 15:00- 17:00</h6>
					<h6 style="padding-left:16px;"><B>Lugogo show ground, Kampala, Uganda</B></h6>	
					<h6 style="padding-left:15px;padding-bottom:3px;">This musical revolves round a Primadon who feels marglinalised and no 
					longer appreciated thw industry. Just.....</h6>	
					<div class="row">
						<h6 style="padding-left:12px;">
						&nbsp; &nbsp; &nbsp; 1 interested
						<a class="black"  style="padding-left:85px; ">
							<span style="color:#BCBCBC;font-size:12;">Posted By</span >  
							<img src="images/icons/great_music.jpg" class="img-circle" style="width:25px;height:25px">
							<B><span style="color:#626262;">Steven Byamugisha 11</span></B>
						</a>
						</h6>
					</div>
					
						
					
				</div> 
			</div>
		</div>
			
	</div>
</div>
<div class="panel panel-default" style="border:none; border-radius:0px"> 
	<div class="panel-body">
	
		<div class="row">
			<div class="col-lg-3 col-sm-3 col-md-3 col-xs-3">
				<a  class="btn" href="events2.php">
					<img src="images/profiles/right hand side 3.png" width="130px" height="150px">
				</a>
			</div>
			<div class="col-lg-9 col-sm-9 col-md-9 col-xs-9" >
				 <div class="caption">
					<span style="padding-left:2px;" ><a  class="btn" href="events2.php" ><B><span class="redbright">Kampala Hood Hunters</span></B></a></span>
					<h6 style="padding-left:15px;">Sundy, 20 December, 15:00- 17:00</h6>
					<h6 style="padding-left:16px;"><B>Lugogo show ground, Kampala, Uganda</B></h6>	
					<h6 style="padding-left:15px;padding-bottom:3px;">This musical revolves round a Primadon who feels marglinalised and no 
					longer appreciated thw industry. Just.....</h6>	
					<div class="row">
						<h6 style="padding-left:12px;">
						&nbsp; &nbsp; &nbsp; 1 interested
						<a class="black"  style="padding-left:85px; ">
							<span style="color:#BCBCBC;font-size:12;">Posted By</span >  
							<img src="images/icons/great_music.jpg" class="img-circle" style="width:25px;height:25px">
							<B><span style="color:#626262;">Steven Byamugisha 11</span></B>
						</a>
						</h6>
					</div>
					
						
					
				</div> 
			</div>
		</div>
			
	</div>
</div>
<div class="panel panel-default" style="border:none; border-radius:0px"> 
	<div class="panel-body">
	
		<<div class="row">
			<div class="col-lg-3 col-sm-3 col-md-3 col-xs-3">
				<a  class="btn" href="events2.php">
					<img src="images/profiles/right hand side 3.png" width="130px" height="150px">
				</a>
			</div>
			<div class="col-lg-9 col-sm-9 col-md-9 col-xs-9" >
				 <div class="caption">
					<span style="padding-left:2px;" ><a  class="btn" href="events2.php" ><B><span class="redbright">Kampala Hood Hunters</span></B></a></span>
					<h6 style="padding-left:15px;">Sundy, 20 December, 15:00- 17:00</h6>
					<h6 style="padding-left:16px;"><B>Lugogo show ground, Kampala, Uganda</B></h6>	
					<h6 style="padding-left:15px;padding-bottom:3px;">This musical revolves round a Primadon who feels marglinalised and no 
					longer appreciated thw industry. Just.....</h6>	
					<div class="row">
						<h6 style="padding-left:12px;">
						&nbsp; &nbsp; &nbsp; 1 interested
						<a class="black"  style="padding-left:85px; ">
							<span style="color:#BCBCBC;font-size:12;">Posted By</span >  
							<img src="images/icons/great_music.jpg" class="img-circle" style="width:25px;height:25px">
							<B><span style="color:#626262;">Steven Byamugisha 11</span></B>
						</a>
						</h6>
					</div>
					
					
						
					
				</div> 
			</div>
		</div>
			
	</div>
</div>
<div class="panel panel-default" style="border:none; border-radius:0px"> 
	<div class="panel-body">
	
		<div class="row">
			<div class="col-lg-3 col-sm-3 col-md-3 col-xs-3">
				<a  class="btn" href="events2.php">
					<img src="images/profiles/right hand side 3.png" width="130px" height="150px">
				</a>
			</div>
			<div class="col-lg-9 col-sm-9 col-md-9 col-xs-9" >
				 <div class="caption">
					<span style="padding-left:2px;" ><a  class="btn" href="events2.php" ><B><span class="redbright">Kampala Hood Hunters</span></B></a></span>
					<h6 style="padding-left:15px;">Sundy, 20 December, 15:00- 17:00</h6>
					<h6 style="padding-left:16px;"><B>Lugogo show ground, Kampala, Uganda</B></h6>	
					<h6 style="padding-left:15px;padding-bottom:3px;">This musical revolves round a Primadon who feels marglinalised and no 
					longer appreciated thw industry. Just.....</h6>	
					<div class="row">
						<h6 style="padding-left:12px;">
						&nbsp; &nbsp; &nbsp; 1 interested
						<a class="black"  style="padding-left:85px; ">
							<span style="color:#BCBCBC;font-size:12;">Posted By</span >  
							<img src="images/icons/great_music.jpg" class="img-circle" style="width:25px;height:25px">
							<B><span style="color:#626262;">Steven Byamugisha 11</span></B>
						</a>
						</h6>
					</div>
					
					
						
					
				</div> 
			</div>
		</div>
			
	</div>
</div>