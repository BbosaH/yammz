	                    <div class="row">
						 	<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 col-xl-4">

						 		<div class="form-group">
						 			<p class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-xl-8 more_info_text">Accepts Credit Cards </p>
						 			<select name="more_info_1" id="accepts_credit_card" class="more_info_input col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4" >
										<option value="0" style="font-size:10;font-weight:bold;">NO</option>
										<option value="1" style="font-size:10;font-weight:bold;">YES</option>							
									</select>
						 		</div>

						 		<div class="more_info_space"></div>
						 		<div class="form-group">
						 			<p class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-xl-8 more_info_text">Take Reservations </p>
						 			<select name="more_info_1" id="take_reservation" class="more_info_input col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4" >
										<option value="0" style="font-size:10;font-weight:bold;">NO</option>
										<option value="1" style="font-size:10;font-weight:bold;">YES</option>							
									</select>
						 		</div>

						 		<div class="more_info_space"></div>
						 		<div class="form-group">
						 			<p class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-xl-8 more_info_text">Good for children </p>
						 			<select name="more_info_1" id="good_for_children" class="more_info_input col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4" >
										<option value="0" style="font-size:10;font-weight:bold;">NO</option>
										<option value="1" style="font-size:10;font-weight:bold;">YES</option>							
									</select>
						 		</div>

						 		<div class="more_info_space"></div>
						 		<div class="form-group">
						 			<p class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-xl-8 more_info_text">Good for Dancing</p>
						 			<select name="more_info_1" id="good_for_dancing" class="more_info_input col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4" >
										<option value="0" style="font-size:10;font-weight:bold;">NO</option>
										<option value="1" style="font-size:10;font-weight:bold;">YES</option>							
									</select>
						 		</div>

						 		<div class="more_info_space"></div>
						 		<div class="form-group">
						 			<p class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-xl-8 more_info_text">Good for Groups</p>
						 			<select name="more_info_1" id="good_for_groups" class="more_info_input col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4" >
										<option value="0" style="font-size:10;font-weight:bold;">NO</option>
										<option value="1" style="font-size:10;font-weight:bold;">YES</option>							
									</select>
						 		</div>

						 		<div class="more_info_space"></div>
						 		<div class="form-group">
						 			<p class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-xl-8 more_info_text">Take Away</p>
						 			<select name="more_info_1" id="take_away" class="more_info_input col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4" >
										<option value="0" style="font-size:10;font-weight:bold;">NO</option>
										<option value="1" style="font-size:10;font-weight:bold;">YES</option>							
									</select>
						 		</div>

						 		<div class="more_info_space"></div>
						 		<div class="form-group">
						 			<p class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-xl-8 more_info_text">Delivery</p>
						 			<select name="more_info_1" id="delivery" class="more_info_input col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4" >
										<option value="0" style="font-size:10;font-weight:bold;">NO</option>
										<option value="1" style="font-size:10;font-weight:bold;">YES</option>							
									</select>
						 		</div>
						 		<div class="more_info_space"></div>
						 		<div class="form-group">
						 			<p class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-xl-8 more_info_text">Music</p>
						 			<select name="more_info_1" id="music" class="more_info_input col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4" >
										<option value="0" style="font-size:10;font-weight:bold;">NO</option>
										<option value="1" style="font-size:10;font-weight:bold;">YES</option>							
									</select>
						 		</div>

						 	</div>
						 	<div class="hidden-xs hidden-sm col-md-1 col-lg-1 col-xl-1">

						 		<p class="pull-right">
						 			<hr style="height:400px;width:8px;background-color:#EBEAEF;margin-top:-20px;"></hr>
						 		</p>

						 	</div>
						 	<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 col-xl-4">
						 	
						 		<div class="form-group">
						 			<p class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-xl-8 more_info_text">Outdoor Seating</p>
						 			<select name="more_info_1" id="outdoor_seating" class="more_info_input col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4" >
										<option value="0" style="font-size:10;font-weight:bold;">NO</option>
										<option value="1" style="font-size:10;font-weight:bold;">YES</option>							
									</select>
						 		</div>

						 		<div class="more_info_space"></div>
						 		<div class="form-group">
						 			<p class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-xl-8 more_info_text">Has Pool Table </p>
						 			<select name="more_info_1" id="has_pool_table" class="more_info_input col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4" >
										<option value="0" style="font-size:10;font-weight:bold;">NO</option>
										<option value="1" style="font-size:10;font-weight:bold;">YES</option>							
									</select>
						 		</div>

						 		<div class="more_info_space"></div>
						 		<div class="form-group">
						 			<p class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-xl-8 more_info_text">Waiter Service </p>
						 			<select name="more_info_1" id="waiter_service" class="more_info_input col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4" >
										<option value="0" style="font-size:10;font-weight:bold;">NO</option>
										<option value="1" style="font-size:10;font-weight:bold;">YES</option>							
									</select>
						 		</div>

						 		<div class="more_info_space"></div>
						 		<div class="form-group">
						 			<p class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-xl-8 more_info_text">Happy Hour</p>
						 			<select name="more_info_1" id="happy_hour" class="more_info_input col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4" >
										<option value="0" style="font-size:10;font-weight:bold;">NO</option>
										<option value="1" style="font-size:10;font-weight:bold;">YES</option>							
									</select>
						 		</div>

						 		<div class="more_info_space"></div>
						 		<div class="form-group">
						 			<p class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-xl-8 more_info_text">Best Nights</p>
						 			<select name="more_info_1" id="best_night" class="more_info_input col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4" >
										<option value="0" style="font-size:10;font-weight:bold;">NO</option>
										<option value="1" style="font-size:10;font-weight:bold;">YES</option>							
									</select>
						 		</div>

						 		<div class="more_info_space"></div>
						 		<div class="form-group">
						 			<p class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-xl-8 more_info_text">Alcohol</p>
						 			<select name="more_info_1" id="alcohol" class="more_info_input col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4" >
										<option value="0" style="font-size:10;font-weight:bold;">NO</option>
										<option value="1" style="font-size:10;font-weight:bold;">YES</option>							
									</select>
						 		</div>

						 		<div class="more_info_space"></div>
						 		<div class="form-group">
						 			<p class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-xl-8 more_info_text">Has TV</p>
						 			<select name="more_info_1" id="has_tv" class="more_info_input col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4" >
										<option value="0" style="font-size:10;font-weight:bold;">NO</option>
										<option value="1" style="font-size:10;font-weight:bold;">YES</option>							
									</select>
						 		</div>
						 		<div class="more_info_space"></div>
						 		<div class="form-group">
						 			<p class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-xl-8 more_info_text">Wi-Fi</p>
						 			<select  name="more_info_1" id="has_wifi" class="more_info_input col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4"  >
										<option value="0" style="font-size:10;font-weight:bold;">NO</option>
										<option value="1" style="font-size:10;font-weight:bold;">YES</option>							
									</select>
						 		</div>
						 	
						 	</div>
						 </div>
						 
									