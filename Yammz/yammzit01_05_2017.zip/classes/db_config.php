<?php

define('DB_USER', "root");
define('DB_PASSWORD', "");
//define('DB_DATABASE', "yammzit");
define('DB_DATABASE', "yammzitc_final");
define('DB_SERVER', "localhost");
define('BaseURL','http://localhost//yammzit/Yammz/');
define('BaseImageURL','http://localhost//yammzit/admin/Theme/');

// define('DB_USER', "9eb574_henrys");
// define('DB_PASSWORD', "henry_1234");
// define('DB_DATABASE', "db_9eb574_henrys");
// define('DB_SERVER', "MYSQL5016.Smarterasp.net");
// define('BaseURL','http://yammzit.com/');
// define('BaseImageURL','http://yammzit.com/admin/Theme/')


// define('DB_USER', "9eb574_yammzit");
// define('DB_PASSWORD', "yammz.1234");
// define('DB_DATABASE', "db_9eb574_yammzit");
// define('DB_SERVER', "MYSQL5014.Smarterasp.net");
// define('BaseURL','http://yammzco-001-site1.btempurl.com/');
// define('BaseImageURL','http://yammzco-001-site1.btempurl.com/admin/Theme/')

// define('DB_USER', "9eb574_yammzit");
// define('DB_PASSWORD', "yammz.1234");
// define('DB_DATABASE', "db_9eb574_yammzit");
// define('DB_SERVER', "MYSQL5014.Smarterasp.net");
// // define('BaseURL','http://localhost:89//yammzit/Yammz/');
// // define('BaseImageURL','http://localhost:89//yammzit/admin/Theme/')

//final database......

// define('DB_USER', "9eb574_final");
// define('DB_PASSWORD', "yammz.1234");
// define('DB_DATABASE', "db_9eb574_final");
// define('DB_SERVER', "MYSQL5009.Smarterasp.net");
// define('BaseURL','http://yammzit.com/');
// define('BaseImageURL','http://yammzit.com/admin/Theme/')


?>
