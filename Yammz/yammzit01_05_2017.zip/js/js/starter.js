/**
* starter Module
*
* Description
*/
'use strict';

angular.module('starter', ['home']).config([function() {

}]).
run([ function(){
	console.log("starter application running");

}])
