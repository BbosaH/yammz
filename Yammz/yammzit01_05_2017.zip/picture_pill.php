

<div>

<img src="<?php echo $feed['photo']; ?>"  style="width:440px;height:250px"  alt="Generic placeholder thumbnail">

</div>