<div class="collapse navbar-collapse navbar-static-bottom" style="padding-bottom:0px; margin-left: -16px;">
	<div class="row">
		<div class="container">
			<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12"  >
				<div class="panel panel-default" style="background-color:#F5F6F1;padding-bottom:0px; padding-left:20px;padding-right:20px;">
					<div class="panel-body">
						<div class="row">
							<div class="col-lg-2 col-sm-2 col-md-2 col-xs-2">
								<B>BUSINESSES</B>
								<h1></h1>
								<h6 ><a href="#" class="simplegrey">Claim your business page</a></h6>
								<h6><a href="#" class="simplegrey">Business support</a></h6>
								<h6><a href="#" class="simplegrey">Ad choices</a></h6>
							</div>
							<div class="col-lg-2 col-sm-2 col-md-2 col-xs-2">
								<B>YAMMZIT</B>
								<h1></h1>
								<h6><a href="#" class="simplegrey">About yammzit</a></h6>
								<h6><a href="#" class="simplegrey">Contact yammzit</a></h6>
							</div>
							<div class="col-lg-2 col-sm-2 col-md-2 col-xs-2">
								
								<B>POLICIES</B>
								<h1></h1>
								<h6><a href="#" class="simplegrey">Privacy policy</a></h6>
								<h6><a href="#" class="simplegrey">Content guidelines</a></h6>
								<h6><a href="#" class="simplegrey">Terms of service</a></h6>
							</div>
							<div class="col-lg-2 col-sm-2 col-md-2 col-xs-2">
								<B>MOBILE</B>
								<h1></h1>
								<h6><a href="#" class="simplegrey">Android</a></h6>
							</div>
							<div class="col-lg-2 col-sm-2 col-md-2 col-xs-2">
								<B>SOCIAL MEDIA</B>
								<h1></h1>
								<table>
									<tr height="40px;">
										<td width="40px">
											<a href="#" class="simplegrey"><img src="images/icons/official-youtube-logo.png" class="img-responsive" style="width:30px;height:30px"  alt="Generic placeholder thumbnail Responsive image"></a>
										</td>
										<td >
											<a href="#" class="simplegrey"><img src="images/icons/Facebook_logo_square.png" class="img-responsive" style="width:30px;height:30px"  alt="Generic placeholder thumbnail Responsive image"></a>
										</td>
									</tr>
									
									<tr>
									
										<td width="40px">
											<a href="#" class="simplegrey"><img src="images/icons/Twitter-icon.png" class="img-responsive" style="width:30px;height:30px"  alt="Generic placeholder thumbnail Responsive image"></a>
										</td>
										<td>
											<a href="#" class="simplegrey"><img src="images/icons/Instagram-logo-005.png" class="img-responsive" style="width:30px;height:30px"  alt="Generic placeholder thumbnail Responsive image"></a>
										</td>
									</tr>
								</table>
							</div>
							<div class="col-lg-2 col-sm-2 col-md-2 col-xs-2">
								<B>PARTNERS</B>
								<h1></h1>
								<a href="#" style="text-decoration:none;" class="simplegrey"><img src="images/icons/yammz_logo.png" width="50" height="60" /></a>
							</div>
						</div>
						<br/>
						<br/>
						<br/>
						<br/>
						<br/>
						<br/>
						<p > <h6 class="pull-left simplegrey">By using this website, you agree to our Terms of service, cookie Polict, Privacy policy and Content Policy</h6></p>
					</div>
				 </div>
			</div>
		</div>
	</div>
</div>