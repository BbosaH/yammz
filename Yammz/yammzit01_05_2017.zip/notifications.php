<?php
require_once('Controllers/auth/auth.php');
?>

<html lang="en">
	<?php require_once('imports.php'); ?>
	<body style="background-color:#E9EAEE">
		
	<?php require_once('Controllers/Logged_header2.php');?>
		<div class="container">
			
			<div class="row">
				<div class="container">
				<div class="row" style="padding-top:5px">
				
				</div>
				<br/>
					<div class="col-lg-8 col-sm-8 col-md-8 col-xs-12"  >
						<table style="width:2000px;background-color:white;">
							<tr >
								<td colspan="2" style="padding-left:45px;padding-top:15px;" class="redbright">NOTIFICATIONS</td>
							</tr >
							<tr >
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14; padding-right:290px;">
									<span>
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
								</td>
							</tr>
							<tr style=" background-color:#E4D4D5; ">
								
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14;padding-right:290px;">
									<span >
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
									<br/>
								</td>
							</tr>
							<tr >
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14; padding-right:290px;">
									<span>
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
								</td>
							</tr>
							<tr >
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14; padding-right:290px;">
									<span>
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
								</td>
							</tr>
							<tr style=" background-color:#E4D4D5; ">
								
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14;padding-right:290px;">
									<span >
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
									<br/>
								</td>
							</tr>
							<tr style=" background-color:#E4D4D5; ">
								
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14;padding-right:290px;">
									<span >
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
									<br/>
								</td>
							</tr>
							<tr >
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14; padding-right:290px;">
									<span>
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
								</td>
							</tr>
							<tr >
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14; padding-right:290px;">
									<span>
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
								</td>
							</tr>
							<tr style=" background-color:#E4D4D5; ">
								
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14;padding-right:290px;">
									<span >
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
									<br/>
								</td>
							</tr>
							<tr >
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14; padding-right:290px;">
									<span>
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
								</td>
							</tr>
							<tr style=" background-color:#E4D4D5; ">
								
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14;padding-right:290px;">
									<span >
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
									<br/>
								</td>
							</tr>
							<tr >
								<td style="padding-left:40px;padding-top:10px;padding-bottom:10px;"><img  class="img-circle"src="images/icons/2.png" width="55px"/></td>
								<td style="font-size:14; padding-right:290px;">
									<span>
										Steven Byamugisha liked your review
									</span><br/>
									<span style="color:#C1C1C1;">30 min ago</span>
								</td>
							</tr>
						
						</table>
					</div>
					
					
					<div class="col-lg-4 col-sm-4 col-md-4 col-xs-12" >
					<!--style="height: 100%;overflow: scroll;" -->
					
						<div class="panel panel-default">
							<div class="panel-body">
								<a href="add_business.php" class="btn btn-default btn-block btn-primary"  style="border-radius:3;background-color:#BD2532; border-radius:10px; border-color:#BE2633; height:70px; width:280px">
									<span style="padding-left:2px"><img src="images/icon_files_white/claim business icon.png" width="40px"/></span>&nbsp;&nbsp;&nbsp;&nbsp;
									
									<span style="font-size:14px; color:#E5DDDD;"><B>Add Business</B> </span>
								</a>
								<hr style="height:4px;"></hr>
								<a type="button" href="claim_business.php" class="btn btn-default btn-block btn-primary"  style="background-color:#BE2633; border-radius:10px; border-color:#BE2633; height:70px; width:280px">
									<span ><img src="images/icon_files_white/claim business icon.png" width="40px"/></span>&nbsp;&nbsp;
									<span style="font-size:14px; color:#E5DDDD;"><B>Claim your business</B> </span>
								</a>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-body">
								<?php require_once("Controllers/latest_events.php"); ?>
								
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-body">
								<?php require_once("Controllers/latest_gossip.php");?>
								
							</div>
						</div>
						<?php require_once("Controllers/business_ads.php")?>
						
					</div>
				</div>
			</div>
			<div class="row">
				<div class="container">
					<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12"  >
						<div class="panel panel-default" style="background-color:#F5F6F1;padding-bottom:0px; padding-left:20px;padding-right:20px;">
							<div class="panel-body">
								<div class="row">
									<div class="col-lg-2 col-sm-2 col-md-2 col-xs-2">
										<B>BUSINESSES</B>
										<h1></h1>
										<h6 ><a href="#" class="simplegrey">Claim your business page</a></h6>
										<h6><a href="#" class="simplegrey">Business support</a></h6>
										<h6><a href="#" class="simplegrey">Ad choices</a></h6>
									</div>
									<div class="col-lg-2 col-sm-2 col-md-2 col-xs-2">
										<B>YAMMZIT</B>
										<h1></h1>
										<h6><a href="#" class="simplegrey">About yammzit</a></h6>
										<h6><a href="#" class="simplegrey">Contact yammzit</a></h6>
									</div>
									<div class="col-lg-2 col-sm-2 col-md-2 col-xs-2">
										
										<B>POLICIES</B>
										<h1></h1>
										<h6><a href="#" class="simplegrey">Privacy policy</a></h6>
										<h6><a href="#" class="simplegrey">Content guidelines</a></h6>
										<h6><a href="#" class="simplegrey">Terms of service</a></h6>
									</div>
									<div class="col-lg-2 col-sm-2 col-md-2 col-xs-2">
										<B>MOBILE</B>
										<h1></h1>
										<h6><a href="#" class="simplegrey">Android</a></h6>
									</div>
									<div class="col-lg-2 col-sm-2 col-md-2 col-xs-2">
										<B>SOCIAL MEDIA</B>
										<h1></h1>
										<table>
											<tr>
												<td size="10px">
													<a href="#" class="simplegrey"><img src="images/icons/official-youtube-logo.png" class="img-responsive" style="width:30px;height:30px"  alt="Generic placeholder thumbnail Responsive image"></a>
												</td>
												<td >
													<a href="#" class="simplegrey"><img src="images/icons/Facebook_logo_square.png" class="img-responsive" style="width:30px;height:30px"  alt="Generic placeholder thumbnail Responsive image"></a>
												</td>
											</tr>
											
											<tr>
											
												<td>
													<a href="#" class="simplegrey"><img src="images/icons/Twitter-icon.png" class="img-responsive" style="width:30px;height:30px"  alt="Generic placeholder thumbnail Responsive image"></a>
												</td>
												<td>
													<a href="#" class="simplegrey"><img src="images/icons/Instagram-logo-005.png" class="img-responsive" style="width:30px;height:30px"  alt="Generic placeholder thumbnail Responsive image"></a>
												</td>
											</tr>
										</table>
									</div>
									<div class="col-lg-2 col-sm-2 col-md-2 col-xs-2">
										<B>PARTNERS</B>
										<h1></h1>
										<a href="#" class="simplegrey"><img src="images/icons/yammz_logo.png" width="50" height="60" /></a>
									</div>
								</div>
								<br/>
								<br/>
								<br/>
								<br/>
								<br/>
								<br/>
								<p > <h6 class="pull-left simplegrey">By using this website, you agree to our Terms of service, cookie Polict, Privacy policy and Content Policy</h6></p>
							</div>
						 </div>
					</div>
				</div>
			</div>
		</div>
		<script src="dist/js/bootstrap.min.js"></script>
		<script src="assets/js/docs.min.js"></script>
		<script src="offcanvas.js"></script>
	</body>

</html>