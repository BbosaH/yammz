<!-- Start of check in for business -->
<div class="panel panel-default no_border">
	<div class="panel-body">
		<!-- Start row with the right most three dots -->
	<!-- 	<div class="row">
			<div class="col-md-10 col-lg-10 col-sm-10 col-xl-10 col-xs-10"></div>
			<div class="col-md-2 col-lg-2 col-sm-2 col-xl-2 col-xs-2">
				<div class="badge right_most_top_Outer_badge" >
					<div class="icon icon-carnival48 " style="font-size:26px;margin-top:17px;"></div>
				</div>
			</div>
		</div>
 -->
		<div class="row">
						<div class="col-md-10 col-lg-10 col-sm-10 col-xl-10 col-xs-10"></div>
						<div class="col-md-2 col-lg-2 col-sm-2 col-xl-2 col-xs-2">
							<div class="badge right_most_top_Outer_badge" >
								<div class="icon icon-map-pointer7 badge_icon_position"></div>
							</div>
						</div>
					</div>
		<!-- End of row with the right most three dots -->

		<!-- Start of row with the user profile photo,name,date, welcome note ,like,comments and commenting field -->
		<div class="row">
			<!-- column with avatar -->
			<div class="col-md-2 col-lg-2 col-sm-2 col-xl-2 col-xs-2 right_space">
				<div class="outer_profile_letter">
					<div class="outer_profile_letter_center">B</div>					
				</div>
			</div>
			<!-- End of column with avatar -->
			<!-- Start of column with user profile photo,name,date, welcome note ,like,comments nd commenting field -->
			<div class="col-md-10 col-lg-10 col-sm-10 col-xl-10 col-xs-10 profile_name_section_left">
				
				<h6>					
					<span class="profile_name">Steven Byamugisha II <span style="font-weight:lighter">checked in at </span> Cafe Javas </span><br/>
					<span class="help-block " style="color:#CFCFCF;">06/06/2016 3hrs ago</span>
				</h6>
			</div>
		</div>
		<div class="row like_commenting_row">
			<!-- <div class="col-md-1 col-lg-1 col-sm-1 col-xl-1 col-xs-1"></div> -->
			<div class="col-md-12 col-lg-12 col-sm-12 col-xl-12 col-xs-12 ">
				
				<img src="../../admin/Theme/uploads/7333626_orig.jpg" style="width:100%;height:200px;">
				<p class="redbright" style="margin-bottom:1px;margin-top:10px;">Cafe Javas</p>
				
				<div class="profile_updte_time" style="margin-bottom:5px;">Plot 36 Bukoto, Kampala, Uganda</div>
				
				<div class="row">
					<div class="col-md-5 col-lg-5 col-sm-5 col-xl-5 col-xs-5 ">
						<i class="ion ion-ios-star-outline redbright discovered_rate_icon_size" />
						<i class="ion ion-ios-star-outline redbright discovered_rate_icon_size" />	
						<i class="ion ion-ios-star-outline redbright discovered_rate_icon_size"/>	
						<i class="ion ion-ios-star-outline redbright discovered_rate_icon_size" />	
						<i class="ion ion-ios-star-outline redbright discovered_rate_icon_size" />							
					</div>

					<div class="col-md-5 col-lg-5 col-sm-5 col-xl-5 col-xs-5 ">						
						<i class="ion ion-social-usd-outline price_icon_style discovered_rate_icon_size"/>
						<i class="ion ion-social-usd-outline price_icon_style discovered_rate_icon_size" />
						<i class="ion ion-social-usd-outline price_icon_style discovered_rate_icon_size"/>
						<i class="ion ion-social-usd-outline price_icon_style discovered_rate_icon_size"/>
						<i class="ion ion-social-usd-outline price_icon_style discovered_rate_icon_size"/>
					</div>
					<div class="col-md-2 col-lg-2 col-sm-2 col-xl-2 col-xs-2">
						<div class="icon icon-add182" style="color:#ECCB37;font-size:16px;margin-top:-15px;"></div>
						<div style="font-size:10px;margin-left:-7px;color:#C4C4C4;margin-top:4px;">Follow</div>
					</div>
				</div>
			</div>
			
		</div>
		<div class="row ">
			<div class="col-md-12 col-lg-12 col-sm-12 col-xl-12 col-xs-12">	
				<hr class="horizontal_line" style="margin-top:8px;"></hr>
				<!-- Row with like button and comment button-->
				<div class="row like_commenting_row">
					<div class="col-md-4 col-lg-4 col-sm-12 col-xl-4 col-xs-12">
						<a href="javascript:void();"  style="font-size:9px; background-color:white;text-decoration:none;" id="">
							<span class="icon icon-like85 redbright " style="font-size:16px;"> &nbsp;
								<span class="simplegrey" style="font-size:12;margin-left:-7px;">10 </span>&nbsp;
								<span style="font-size:12;margin-left:-7px;" class="simplegrey">Likes</span>
						</a>
					</div>
					<div class="col-md-4 col-lg-4 col-sm-12 col-xl-4 col-xs-12" style="margin-left:-40px;">
						<a class=" btn simplegrey "style="text-decoration:none;"  data-toggle="collapse" data-target="#comment">
						<div class="row">
							<div style="font-size:16px;margin-top:-3px;" class="glyphicon glyphicon-comment col-md-2 col-lg-2 col-sm-2 col-xl-2 col-xs-2 pull-left"></div>
							<div class="simplegrey col-md-1 col-lg-1 col-sm-1 col-xl-1 col-xs-1" style="font-size:12;margin-left:-7px;font-weight:bold;margin-top:-3px;">2 </div>
							<div class="simplegrey col-md-5 col-lg-5 col-sm-5 col-xl-5 col-xs-5" style="font-size:12;margin-left:-18px;margin-top:-3px;font-weight:bold;">Comments</div>
						</div>	
						</a>
					</div>
					<div class="col-md-4 col-lg-4 col-sm-12 col-xl-4 col-xs-12" style="margin-left:0px;">
						<a class=" btn simplegrey "style="text-decoration:none;"  data-toggle="collapse" data-target="#comment">
						<div class="row">
							<div style="font-size:16px;margin-top:-3px;" class="icon icon-sharing6 col-md-2 col-lg-2 col-sm-2 col-xl-2 col-xs-2 pull-left"></div>
							<div class="simplegrey col-md-1 col-lg-1 col-sm-1 col-xl-1 col-xs-1" style="font-size:12;margin-left:-7px;font-weight:bold;margin-top:-3px;">2 </div>
							<div class="simplegrey col-md-5 col-lg-5 col-sm-5 col-xl-5 col-xs-5" style="font-size:12;margin-left:-18px;margin-top:-3px;font-weight:bold;">Shares</div>
						</div>	
						</a>
					</div>
				</div>
				<!-- End of Row with like and comment buttons -->
				<!-- start of Row with comment field -->
				<div class="row like_commenting_row">
					<div class="col-md-10 col-lg-10 col-sm-10 col-xl-10 col-xs-10">
						<form action="" >
							<div class="form-group">
								<input type="text" class="form-control comment_field" placeholder="Write a comment....">
							</div>
						</form>

					</div>
					<div class="col-md-2 col-lg-2 col-sm-2 col-xl-2 col-xs-2 send_button_column">
						<button class="post_send_button">Send</button>
					</div>
				</div>
				<!-- End of Row with comment field -->
			</div>
			<!-- Start of column with user profile photo,name,date, welcome note ,like,comments nd commenting field -->
		</div>
		<!-- End of row with the user profile photo,name,date, welcome note ,like,commentss nd commenting -->
	</div>
</div>
<!-- End of check in -->

<!-- Start of shared check in -->
<div class="panel panel-default no_border">
	<div class="panel-body">	

		<!-- Start of row with the user profile photo,name,date, welcome note ,like,comments and commenting field -->
		<div class="row">
			<!-- column with avatar -->
			<div class="col-md-2 col-lg-2 col-sm-2 col-xl-2 col-xs-2 right_space">
				<div class="outer_profile_letter">
					<div class="outer_profile_letter_center">B</div>					
				</div>
			</div>
			<!-- End of column with avatar -->
			<!-- Start of column with user profile photo,name,date, welcome note ,like,comments nd commenting field -->
			<div class="col-md-10 col-lg-10 col-sm-10 col-xl-10 col-xs-10 profile_name_section_left">			
				<h6>					
					<span class="profile_name">Steven Byamugisha II <span style="font-weight:lighter">shared</span> Kevin Gasta's <span style="font-weight:lighter">post</span></span><br/>
					<span class="help-block " style="color:#CFCFCF;">06/06/2016 3hrs ago</span>
				</h6>
			</div>
		</div>
		<div class="row">
			<!-- <div class="col-md-1 col-lg-1 col-sm-1 col-xl-1 col-xs-1"></div> -->
			<div class="col-md-12 col-lg-12 col-sm-12 col-xl-12 col-xs-12">

				<div class="empty_right_side_frame">
					<!-- Start row with the right most badge -->
					<div class="row">
						<div class="col-md-10 col-lg-10 col-sm-10 col-xl-10 col-xs-10"></div>
						<div class="col-md-2 col-lg-2 col-sm-2 col-xl-2 col-xs-2">
							<div class="badge right_most_top_inner_badge" >
								<div class="icon icon-map-pointer7 badge_icon_position"></div>
							</div>
						</div>
					</div>
					<!-- End of row with the right most badge -->
					<div class="row" style="margin-top:5px;margin-bottom:10px;margin-left:0px;">
						<div class="col-md-1 col-lg-1 col-sm-1 col-xl-1 col-xs-1 right_space">	
							<div class="inner_profile_letter">
								<div class="inner_profile_letter_center">K</div>	
							</div>
						</div>
						<div class="col-md-10 col-lg-10 col-sm-10 col-xl-10 col-xs-10">
							<div class="profile_name">Kevin Gasta <span style="font-weight:lighter;">checked in at </span> Cafe Javas</div>
							<div class="profile_updte_time">06/06/2016 3hrs ago</div>

						</div>
					</div>
					<div class="row" style="margin-left:0px;" >
						<div class="col-md-12 col-lg-12 col-sm-12 col-xl-12 col-xs-12">
						
							<img src="../../admin/Theme/uploads/7333626_orig.jpg" style="width:100%;height:200px;">
							<p class="redbright" style="margin-bottom:1px;margin-top:10px;">Cafe Javas</p>
				
							<div class="profile_updte_time" style="margin-bottom:5px;">Plot 36 Bukoto, Kampala, Uganda</div>
							
							<div class="row">
								<div class="col-md-5 col-lg-5 col-sm-5 col-xl-5 col-xs-5 ">
									<i class="ion ion-ios-star-outline redbright discovered_rate_icon_size" />
									<i class="ion ion-ios-star-outline redbright discovered_rate_icon_size" />	
									<i class="ion ion-ios-star-outline redbright discovered_rate_icon_size"/>	
									<i class="ion ion-ios-star-outline redbright discovered_rate_icon_size" />	
									<i class="ion ion-ios-star-outline redbright discovered_rate_icon_size" />							
								</div>

								<div class="col-md-5 col-lg-5 col-sm-5 col-xl-5 col-xs-5 ">						
									<i class="ion ion-social-usd-outline price_icon_style discovered_rate_icon_size"/>
									<i class="ion ion-social-usd-outline price_icon_style discovered_rate_icon_size" />
									<i class="ion ion-social-usd-outline price_icon_style discovered_rate_icon_size"/>
									<i class="ion ion-social-usd-outline price_icon_style discovered_rate_icon_size"/>
									<i class="ion ion-social-usd-outline price_icon_style discovered_rate_icon_size"/>
								</div>
								<div class="col-md-2 col-lg-2 col-sm-2 col-xl-2 col-xs-2">
									<div class="icon icon-add182" style="color:#ECCB37;font-size:16px;margin-top:-15px;"></div>
									<div style="font-size:10px;margin-left:-7px;color:#C4C4C4;margin-top:4px;">Follow</div>
								</div>
							</div>
							<div style="height:5px;"></div>							
						</div>
					</div>
				</div>
			</div>			
		</div>
		<div class="row ">
			<div class="col-md-12 col-lg-12 col-sm-12 col-xl-12 col-xs-12">				
				<!-- Row with like button and comment button-->
				<div class="row like_commenting_row" style="margin-top:10px;">
					<div class="col-md-4 col-lg-4 col-sm-12 col-xl-4 col-xs-12">
						<a href="javascript:void();"  style="font-size:9px; background-color:white;text-decoration:none;" id="">
							<span class="icon icon-like85 redbright " style="font-size:16px;"> &nbsp;
								<span class="simplegrey" style="font-size:12;margin-left:-7px;">10 </span>&nbsp;
								<span style="font-size:12;margin-left:-7px;" class="simplegrey">Likes</span>
						</a>
					</div>
					<div class="col-md-4 col-lg-4 col-sm-12 col-xl-4 col-xs-12" style="margin-left:-40px;">
						<a class=" btn simplegrey "style="text-decoration:none;"  data-toggle="collapse" data-target="#comment">
						<div class="row">
							<div style="font-size:16px;margin-top:-3px;" class="glyphicon glyphicon-comment col-md-2 col-lg-2 col-sm-2 col-xl-2 col-xs-2 pull-left"></div>
							<div class="simplegrey col-md-1 col-lg-1 col-sm-1 col-xl-1 col-xs-1" style="font-size:12;margin-left:-7px;font-weight:bold;margin-top:-3px;">2 </div>
							<div class="simplegrey col-md-5 col-lg-5 col-sm-5 col-xl-5 col-xs-5" style="font-size:12;margin-left:-18px;margin-top:-3px;font-weight:bold;">Comments</div>
						</div>	
						</a>
					</div>
					<div class="col-md-4 col-lg-4 col-sm-12 col-xl-4 col-xs-12" style="margin-left:0px;">
						<a class=" btn simplegrey "style="text-decoration:none;"  data-toggle="collapse" data-target="#comment">
						<div class="row">
							<div style="font-size:16px;margin-top:-3px;" class="icon icon-sharing6 col-md-2 col-lg-2 col-sm-2 col-xl-2 col-xs-2 pull-left"></div>
							<div class="simplegrey col-md-1 col-lg-1 col-sm-1 col-xl-1 col-xs-1" style="font-size:12;margin-left:-7px;font-weight:bold;margin-top:-3px;">2 </div>
							<div class="simplegrey col-md-5 col-lg-5 col-sm-5 col-xl-5 col-xs-5" style="font-size:12;margin-left:-18px;margin-top:-3px;font-weight:bold;">Shares</div>
						</div>	
						</a>
					</div>
				</div>
				<!-- End of Row with like and comment buttons -->
				<!-- start of Row with comment field -->
				<div class="row like_commenting_row">
					<div class="col-md-10 col-lg-10 col-sm-10 col-xl-10 col-xs-10">
						<form action="" >
							<div class="form-group">
								<input type="text" class="form-control comment_field" placeholder="Write a comment....">
							</div>
						</form>

					</div>
					<div class="col-md-2 col-lg-2 col-sm-2 col-xl-2 col-xs-2 send_button_column">
						<button class="post_send_button">Send</button>
					</div>
				</div>
				<!-- End of Row with comment field -->
			</div>
			<!-- Start of column with user profile photo,name,date, welcome note ,like,comments nd commenting field -->
		</div>
		<!-- End of row with the user profile photo,name,date, welcome note ,like,commentss nd commenting -->
	</div>
</div>
<!-- End of shared check in -->